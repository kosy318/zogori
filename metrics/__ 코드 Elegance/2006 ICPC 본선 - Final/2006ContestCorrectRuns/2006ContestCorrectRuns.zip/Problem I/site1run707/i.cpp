#include <cstdio>
#include <iostream>
#include <stack>

#define EPSILON 0.0000001

using namespace std;

struct Point
{
	double x,y;
};

struct Point ptr[2000];
int n;
double maxheight[2000];
double watangka;
double minimum;

struct Point up[2000];
struct Point down[2000];
int m,mm;

inline double det(double x11,double x12,double x21,double x22)
{
	return x11*x22-x12*x21;
}

inline double abs(double a)
{
	if(a<0) return -a; else return a;
}

int getCrossP(Point a,Point b,Point p,Point q,Point &cp)
{
	double mdet=det(b.x-a.x,p.x-q.x,b.y-a.y,p.y-q.y);
	if(abs(mdet)<EPSILON) return 0;
	double t1=det(p.x-a.x,p.x-q.x,p.y-a.y,p.y-q.y) / mdet;
	double t2=det(b.x-a.x,p.x-a.x,b.y-a.y,p.y-a.y) / mdet;
	if(t1 < - EPSILON || t1 > 1 + EPSILON || t2 < - EPSILON || t2 > 1 + EPSILON) return -1;
	cp.x=p.x+t2*(q.x-p.x);
	cp.y=p.y+t2*(q.y-p.y);
	return 1;
}

int main(void)
{
	int T,i,j;
	scanf("%d",&T);
	while(T--)
	{
		minimum=1001;
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			scanf("%lf %lf",&ptr[i].x,&ptr[i].y);
			maxheight[i]=0;
		}

		for(i=1;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				maxheight[j] >?=(ptr[i].y-ptr[i-1].y)/(ptr[i].x-ptr[i-1].x) * (ptr[j].x-ptr[i-1].x) +ptr[i-1].y;
			}
		}

		for(j=0;j<n;j++)
		{
			if(minimum > maxheight[j]-ptr[j].y)
			{
				minimum=maxheight[j]-ptr[j].y;
			}
		}

		m=0;
		for(i=1;i<n;i++)
		{
			if(ptr[i].y > ptr[i-1].y)
			{
				struct Point bound;
				bound.y=ptr[i-1].y + (ptr[n-1].x-ptr[i-1].x) * (ptr[i].y - ptr[i-1].y) / (ptr[i].x - ptr[i-1].x);
				bound.x=ptr[n-1].x;
				// ptr[i-1]~ptr[i]  ... 1
				// vs up[m-2]~up[m-1] ... 2
				// if cross between up[m-2]~up[m-1] , update this.
				// if 1's angle is below 2's, ignore.
				// else pop m;
				if(m==0)
				{
					up[0]=ptr[i-1];
					up[1]=bound;
					m=2;
				}
				else if( (bound.y-ptr[i].y)/(bound.x-ptr[i].x) >
						(up[m-1].y-up[m-2].y)/(up[m-1].x-up[m-2].x))
				{
					struct Point newptr;
					int ret;
					bool flag=false;
					while(m>1)
					{
						if(bound.y < up[m-1].y) break;
						ret=getCrossP(ptr[i-1],bound,up[m-2],up[m-1],newptr);
						if(ret==1)
						{
							up[m]=bound;
							up[m-1]=newptr;

							m++;
							break;
						}
						flag=true;
						m--;
					}
				}
			}
		}

		mm=0;
		for(i=n-2;i>=0;i--)
		{
			if(ptr[i].y > ptr[i+1].y)
			{
				struct Point bound;
				bound.y=ptr[i+1].y + (ptr[0].x-ptr[i+1].x) * (ptr[i+1].y - ptr[i].y) / (ptr[i+1].x - ptr[i].x);
				bound.x=ptr[0].x;

				// ptr[i-1]~ptr[i]  ... 1
				// vs up[m-2]~up[m-1] ... 2
				// if cross between up[m-2]~up[m-1] , update this.
				// if 1's angle is below 2's, ignore.
				// else pop m;
				if(mm==0)
				{
					down[0]=ptr[i+1];
					down[1]=bound;
					mm=2;
				}
				else if( (bound.y-ptr[i].y)/(bound.x-ptr[i].x) <
						(down[mm-1].y-down[mm-2].y)/(down[mm-1].x-down[mm-2].x))
				{
					struct Point newptr;
					int ret;
					bool flag=false;
					while(mm>1)
					{
						if(bound.y < down[mm-1].y) break;
						ret=getCrossP(ptr[i+1],bound,down[mm-2],down[mm-1],newptr);
						if(ret==1)
						{
							down[mm]=bound;
							down[mm-1]=newptr;
							mm++;
							break;
						}
						flag=true;
						mm--;
					}
				}
			}
		}


		i=0;j=mm-1;
		struct Point newptr;

		while(1)
		{
			int ret;
			ret=getCrossP(up[i],up[i+1],down[j-1],down[j],newptr);
			if(ret==1)
			{
				for(i=0;i<n-1;i++)
				{
					if(ptr[i].x <= newptr.x && ptr[i+1].x >= newptr.x)
					{
						struct Point bound;
						bound.y=ptr[i].y + (newptr.x-ptr[i].x) * (ptr[i+1].y - ptr[i].y) / (ptr[i+1].x - ptr[i].x);
						watangka=(newptr.y - bound.y);
						break;
					}
				}
				break;
			}

			if(up[i+1].x < down[j-1].x)
				i++;
			else
				j--;
		}
		if(minimum > watangka)
			minimum = watangka;
		if(minimum>1000)
		{
			printf("IMPOSSIBLE\n");
		}
		else
		{
			printf("%.1lf\n",minimum);
		}
	}
}
