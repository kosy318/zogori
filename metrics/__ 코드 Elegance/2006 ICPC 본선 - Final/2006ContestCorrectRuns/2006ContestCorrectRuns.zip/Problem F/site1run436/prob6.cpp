#include <iostream>
using namespace std;

struct eq {
	int x;
	int c;
};

eq in[20];

int main()
{
	int t, n, sum;
	scanf("%d",&t);
	int x, c;
	int gop;

	for(int i=0; i<t; i++) {
		scanf("%d",&n);

		x = c = 0;
		gop = 1;

		for(int j=0; j<n; j++) {
			scanf("%d %d",&in[j].x,&in[j].c);
			if(!j) gop = in[j].x;
			else {
				if(gop % in[j].x != 0) gop *= in[j].x;
			}
		}		
		scanf("%d",&sum);

		for(int j=0; j<n; j++) {
			//cout << (double)(gop * in[j].c) / (double)in[j].x << endl;
			//c+= (double)(gop * in[j].c) / (double)in[j].x;
			//cout << (double)gop / (double)in[j].x << endl;
			x = x + (double)gop / (double)in[j].x;
			c = c + ((double)gop / (double)in[j].x) * in[j].c;
		}

		sum *= gop;

		//printf("%d %d %d %d\n",gop,x,c,sum);
		
		sum += c;

		if(sum % x == 0) printf("%d\n",sum/x);
		else printf("0\n");
	}

	return 0;
}