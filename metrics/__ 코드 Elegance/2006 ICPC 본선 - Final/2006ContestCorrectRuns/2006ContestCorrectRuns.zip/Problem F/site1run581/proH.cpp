#include <stdio.h>
int arr[100][10000];

int main(void){
	int test_case;
	int data_cnt;
	int a[10000], b[10000];
	int loop, temp, max;
	int i, j, k;
	int index[100];
	int flag;

	scanf("%d", &test_case);

	for(i = 0; i < test_case; i++){

		scanf("%d", &data_cnt);

		for(j = 0; j < data_cnt; j++)
			scanf("%d %d", &a[j], &b[j]);
		scanf("%d", &loop);

		for(j = 0; j < data_cnt; j++)
			for(k = 0; k < loop; k++)
				arr[j][k] = a[j]*k + b[j];
		
		
		max = 0;

		for(j = 0; j < data_cnt; j++)
			index[j] = 0;
		do{
			flag = 1;
			max = arr[0][index[0]];
			

			for(j = 0; j < data_cnt; j++){
				if (arr[j][index[j]] != max)
					flag = 0;
				if (arr[j][index[j]] > max)
					max = arr[j][index[j]];
			}
		
			if (flag == 0)
				for(j = 0; j < data_cnt; j++)
					if (arr[j][index[j]] != max){
						if (index[j] == loop - 1)
							flag = 2;
						index[j]++;
					}

			if (flag == 1){
				temp = 0;
				for(j = 0; j < data_cnt; j++)
					temp = temp + index[j];
				if (temp!= loop) {
					flag = 0;
					
				}
				if (flag == 0)
					for(j = 0; j < data_cnt; j++)
						index[j]++;
			}
	

		}while(flag == 0);

		if (flag != 1) printf("%d\n", 0);
		else printf("%d\n",max);
	}
	return 0;
}