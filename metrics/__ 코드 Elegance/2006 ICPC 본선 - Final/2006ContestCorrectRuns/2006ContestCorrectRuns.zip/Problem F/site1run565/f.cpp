/*
3
3
3 5 4 3 1 7
27
3
3 5 4 3 1 7
26
8
2 156 2 2 2 216 4 12 3 24 5 36 1 96 3 6
695
*/

#include <iostream>
#include <vector>
using namespace std;


int main() {
	int T, N, M;
	vector<int> a, b;
	cin >> T;
	while(T-->0) {
		cin >> N;
		a.clear(); b.clear();
		for(int i=0;i<N;++i) {
			int ta, tb;
			cin >> ta >> tb;
			a.push_back(ta); b.push_back(tb);
		}
		cin >> M;
		int res = 0;
		for(int i=1;i<M;++i) {
			int cnt = 0;
			int f1 = a[0] * i + b[0];
			bool possible = true;
			for(int j=0;j<N;++j) {
				int f2 = f1 - b[j];
				if(f2%a[j]!=0) { possible = false; break; }
				if(f2<0) { possible = false; break; }
				if(f2/a[j]==0) { possible = false; break; }
				cnt += f2/a[j];
			}

			if(!possible) continue;
			if(cnt==M) {
				res = f1;
				break;
			}
		}
		cout << res << endl;
	}
}
