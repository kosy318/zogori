#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 1001
#define WHITE 0
#define GRAY 1
#define BLACK 2


int color[MAX];
int vertex[MAX][MAX];
int time;
int t,n,m,f;
int discoverTime[MAX], finishTime[MAX];


struct edge
{
	int v;
	int w;
};
class stack
{
public:
	edge e[1000000];
    int index;
	void init()
	{
		index=0;
	}
	void push (edge ne)
	{
		e[index++]=ne;
	}
	edge pop ()
	{
		index--;
		edge r=e[index];
		return r;
	}
	edge top()
	{
		return e[index-1];
	}
};
stack s;
edge e[2];
int result = 0;

int min (int a,int b)
{
	if (a>b)
		return b;
	else
		return a;
}
int bicompDFS(int v, int p)
{
	int w;
	int back;

	color[v] = GRAY;
	time++; discoverTime[v] = time;
	back = discoverTime[v];

	for (int i=1;i<=n;++i)
	{
		if (vertex[v][i]==1)
		{
			if (color[i]==WHITE)
			{
				edge tmp;
				tmp.v=v;
				tmp.w=i;
				s.push(tmp);
				int wBack = bicompDFS(i,v);

				if (wBack >= discoverTime[v])
				{
					int re=0;

					edge t1 = s.pop();

					while (!(t1.v==v && t1.w==i))
					{
						if ( (t1.v==e[0].v && t1.w==e[0].w) || (t1.v==e[0].w && t1.w==e[0].v) )
						{
							++re;
						}
						else if ( (t1.v==e[1].v && t1.w==e[1].w) || (t1.v==e[1].w && t1.w==e[1].v) )
							++re;
						t1= s.pop();
					}
if ( (t1.v==e[0].v && t1.w==e[0].w) || (t1.v==e[0].w && t1.w==e[0].v) )
						{
							++re;
						}
						else if ( (t1.v==e[1].v && t1.w==e[1].w) || (t1.v==e[1].w && t1.w==e[1].v) )
							++re;
					if (re == 2)
						result = 1;

				}
				back = min (back, wBack);
			}
			else if(color[i] == GRAY && i!= p)
			{
				edge tmp;
				tmp.v=v;
				tmp.w=i;
				s.push(tmp);
				back = min (discoverTime[i],back);
			}
		}
	}
	time++; finishTime[v] = time;
	color[v] = BLACK;
	return back;
}

void bicomponents ()
{
	time = 0;

	s.init();

	for (int i=1;i<=n;++i)
	{
		if (color[i] == WHITE)
		{
			bicompDFS(i, -1);
		}
	}

}

int main()
{
	scanf ("%d",&t);

	for (int i=0;i<t;++i)
	{
		memset (vertex,0,sizeof(int)*MAX*MAX);
		memset (discoverTime,0,sizeof(int)*MAX);
		memset (finishTime,0,sizeof(int)*MAX);
		memset (color,0,sizeof(int)*MAX);
		result = 0;
		scanf ("%d %d",&n, &m);
		
		for (int j=0;j<m;++j)
		{
			int t1,t2;
			scanf ("%d %d",&t1,&t2);
			vertex[t1][t2]=1;
			vertex[t2][t1]=1;
		}
		scanf ("%d %d",&e[0].v,&e[0].w);
		scanf ("%d %d",&e[1].v,&e[1].w);

		scanf ("%d",&f);
		for (j=0;j<f;++j)
		{
			int t1,t2;
			scanf ("%d %d",&t1,&t2);
			vertex[t1][t2]=0;
			vertex[t2][t1]=0;
		}
		bicomponents ();
		if (result == 1)
			printf ("YES\n");
		else
			printf ("NO\n");
	}
	return 0;
}