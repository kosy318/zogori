#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cstring>


using namespace std;

int N;
vector<int> ans, tmp, adj[51];
bool visited[51], cut[51];
bool flag ;



void dfs(int v) {
	visited[v] = true;
	tmp.push_back(v);

	if (cut[v] && flag) return;
	for (int i = 0; i < adj[v].size(); i++) {
		if (visited[adj[v][i]]==0) {
			dfs(adj[v][i]);
		}
	}
}


void find_food() {
	for (int i = 1; i <= N; i++) {
		dfs(i);
		tmp.clear();
		 memset(visited, false, sizeof(visited));

		visited[i] = 1;
		dfs(adj[i][0]);
		if (tmp.size() != (tmp.size() - 1) )	cut[i] = 1;
		tmp.clear();
		 memset(visited, false, sizeof(visited));
	}
	flag = true;
	for (int i = 1; i <= N; i++) {
		if (cut[i])	continue;
		dfs(i);
		sort(tmp.begin(), tmp.end());
		if (tmp.size() > ans.size() || (tmp.size() == ans.size() && ans > tmp)) ans = tmp;
		tmp.clear();
		memset(visited, false, sizeof(visited));
	}
}

int main(){
	ifstream inFile("food.inp");
	int tmp1, tmp2;
	inFile >> N;
	for (int i = 0; i < N; i++) {
		inFile >> tmp1;
		while (inFile >> tmp2) {
			if (tmp2 == 0)	break;
			adj[tmp1].push_back(tmp2);
		}
	}
	inFile.close();


	find_food();

	ofstream outFile("food.out");
	for (int i = 0; i < ans.size(); i++) outFile << ans[i] << " ";
	return 0;
}
