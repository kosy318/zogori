#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cstring>

#define clean() tmp.clear(), memset(visited, false, sizeof(visited));

using namespace std;

int N, v_size;
vector<int> re, tmp, adj[51];
bool visited[51], cutVertex[51];
bool flag = false;



void dfs(int v) {
	visited[v] = true;
	tmp.push_back(v);
	if ( flag && cutVertex[v] ) return;
	for (int i = 0; i < adj[v].size(); i++) {
		if (!visited[adj[v][i]]) {
			dfs(adj[v][i]);
		}
	}
}

void Floyd_Warshall(int NodeNumber, int(*Distance)[VERTEX_MAX], string(*NodeTable_String)[VERTEX_MAX])
{
	for (int ViaNode = 1; ViaNode <= NodeNumber; ViaNode++)
	{
		for (int StartNode = 1; StartNode <= NodeNumber; StartNode++)
		{
			for (int EndNode = 1; EndNode <= NodeNumber; EndNode++)
			{
				if (Distance[StartNode][EndNode] > Distance[StartNode][ViaNode] + Distance[ViaNode][EndNode])
				{
					Distance[StartNode][EndNode] = Distance[StartNode][ViaNode] + Distance[ViaNode][EndNode];
					NodeTable_String[StartNode][EndNode] = NodeTable_String[StartNode][ViaNode] + " " + NodeTable_String[ViaNode][EndNode];
				}
			}
		}
	}
}

int main(){

	ifstream inFile("food.inp");
	int tmp1, tmp2;
	inFile >> N;
	for (int i = 0; i < N; i++) {
		inFile >> tmp1;
		while (1) {
			inFile >> tmp2;
			if (tmp2 == 0)	break;
			adj[tmp1].push_back(tmp2);
		}
	}

	for (int i = 1; i <= N; i++) {
		dfs(i);
		v_size = tmp.size() - 1;
		clean();
		visited[i] = 1;
		dfs(adj[i][0]);
		if (tmp.size() != v_size)	cutVertex[i] = 1;
		clean();
	}
	flag = true;
	for (int i = 1; i <= N; i++) {
		if (cutVertex[i])	continue;
		dfs(i);
		sort(tmp.begin(), tmp.end());
		if (tmp.size() > re.size() || (tmp.size() == re.size() && re > tmp)) re = tmp;
		clean();
	}

	ofstream outFile("food.out");
	for (int i = 0; i < re.size(); i++) outFile << re[i] << " ";
	

	inFile.close();
	outFile.close();
	return 0;
}
