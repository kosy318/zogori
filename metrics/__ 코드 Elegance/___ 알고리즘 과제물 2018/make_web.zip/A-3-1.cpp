#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cstring>

#define clean() tmp.clear(), memset(visited, false, sizeof(visited));

using namespace std;

int N, v_size;
vector<int> re, tmp, adj[51];
bool visited[51], cutVertex[51];
bool Flag ;

void dfs(int v);


int main(){

	ifstream inFile("food.inp");
	int tmp1, tmp2;
	inFile >> N;
	for (int i = 0; i < N; i++) {
		inFile >> tmp1;
		for(;;) {
			inFile >> tmp2;
			if (tmp2 == 0)	break;
			adj[tmp1].push_back(tmp2);
		}
	}

	for (int i = 1; i <= N; i++) {
		dfs(i);
		v_size = tmp.size() - 1;
		clean();
		visited[i] = 1;
		dfs(adj[i][0]);
		if (tmp.size() != v_size)	cutVertex[i] = 1;
		clean();
	}
	Flag = true;
	for (int i = 1; i <= N; i++) {
		if (cutVertex[i])	continue;
		dfs(i);
		sort(tmp.begin(), tmp.end());
		if (tmp.size() > re.size() ) re = tmp;
		else if(tmp.size() == re.size() && re > tmp) re = tmp;
		clean();
	}

	ofstream outFile("food.out");
	for (int i = 0; i < re.size(); i++) outFile << re[i] << " ";
	

	inFile.close();
	outFile.close();
	return 0;
}

void dfs(int v) {
	visited[v] = true;
	tmp.push_back(v);
	if ( Flag && cutVertex[v] ) return;
	for (int i = 0; i < adj[v].size(); i++) {
		if (!visited[adj[v][i]]) {
			dfs(adj[v][i]);
		}
	}
}
