#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;

typedef struct {
   double x = 0, y = 0, z = 0;
} Point;

int getDistance(Point, Point);
double getDistanceDouble(Point, Point);
Point getPointInLine(Point, Point, double);
int getMinimumLine(Point, Point, Point);
void printPoint(Point);

int main() {

    cout << "read input file" << endl;

    ifstream inp;
    inp.open("connect.inp", ios::in);

    if(!inp.is_open()) {
        cout << "input file is not opened" << endl;
        return EXIT_FAILURE;
    }

    Point a, b, p;
    inp >> a.x >> a.y >> a.z;
    inp >> b.x >> b.y >> b.z;
    inp >> p.x >> p.y >> p.z;

    inp.close();

    int minimumLine = getMinimumLine(a, b, p);

    cout << minimumLine << endl;

    ofstream out;
    out.open("connect.out", ios::out);
    out << minimumLine;
    out.close();

    return 0;
}

int getMinimumLine(Point left, Point right, Point p) {
    double leftLine = getDistanceDouble(left, p);
    double rightLine = getDistanceDouble(right, p);
    Point middlePoint = getPointInLine(left, right, 0.5);
    double middleLine = getDistanceDouble(middlePoint, p);

    cout << "leftLine: " << leftLine << " rightLine: " << rightLine << " middleLine: " << middleLine << endl;

    int count = 0;
    while(true) {
        count++;
        if (leftLine < middleLine) {
            rightLine = middleLine;
            right = middlePoint;
            middlePoint = getPointInLine(left, right, 0.5);
            middleLine = getDistanceDouble(middlePoint, p);
        } else if (rightLine < middleLine) {
            leftLine = middleLine;
            left = middlePoint;
            middlePoint = getPointInLine(left, right, 0.5);
            middleLine = getDistanceDouble(middlePoint, p);
        } else {
            if(leftLine < rightLine) {
                rightLine = middleLine;
                right = middlePoint;
                middlePoint = getPointInLine(left, right, 0.5);
                middleLine = getDistanceDouble(middlePoint, p);
            } else {
                leftLine = middleLine;
                left = middlePoint;
                middlePoint = getPointInLine(left, right, 0.5);
                middleLine = getDistanceDouble(middlePoint, p);
            }
        }

        if (getDistanceDouble(left, right) < 0.000001) {
            cout << "found" << endl;
            break;
        }
    }

    cout << "leftLine: " << leftLine << " rightLine: " << rightLine << " middleLine: " << middleLine << endl;
    cout << "count: " << count << endl;
    return (int)ceil(middleLine);
}

int getDistance(Point a, Point b) {
    return (int)ceil(sqrt((b.x - a.x)*(b.x - a.x) + (b.y - a.y)*(b.y - a.y) + (b.z - a.z) * (b.z - a.z)));
}
double getDistanceDouble(Point a, Point b) {
    return sqrt((b.x - a.x)*(b.x - a.x) + (b.y - a.y)*(b.y - a.y) + (b.z - a.z) * (b.z - a.z));
}
void printPoint(Point p) {
    cout << p.x << " " << p.y << " " << p.z << endl;
}

Point getPointInLine(Point a, Point b, double t) {
    if (t < 0 || t > 1) {
        cout << "invalid 't' value" << endl;
        return a;
    }

    Point result;
    result.x = t * a.x + (1 - t) * b.x;
    result.y = t * a.y + (1 - t) * b.y;
    result.z = t * a.z + (1 - t) * b.z;



    return result;
}

