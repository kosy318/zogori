#include<iostream>
#include<fstream>
#include<math.h>
#include<vector>

using namespace std;
#define Minimum 0.0001f
#define Maximum 1.0f

vector<double> A, B, P, Result;

double dist(vector<double> x, vector<double> y){
    double result=0.0;
    for(int i=0;i<3;i++)result+=(x[i]-y[i])*(x[i]-y[i]);
    return sqrt(result);
}

void f_read(){
    ifstream fin;
    fin.open("connect.inp");
    int x[3];
    fin>>x[0]>>x[1]>>x[2];
    for(int i=0;i<3;i++)A.push_back(x[i]);
    fin>>x[0]>>x[1]>>x[2];
    for(int i=0;i<3;i++)B.push_back(x[i]);
    fin>>x[0]>>x[1]>>x[2];
    for(int i=0;i<3;i++)P.push_back(x[i]);
    for(int i=0;i<3;i++)Result.push_back(0);
}

void calc(vector<double> a, vector<double> b, double step){
    for(int i=0;i<3;i++){
        Result[i]=b[i]*step + a[i]*(1-step);
//        cout<<"x"<<i<<": "<<Result[i]<<" ";
    }
//    cout<<endl;
}

double gradient(vector<double> a, vector<double> b, double mystack){
    vector<double>first, second;

    for(int i=0;i<3;i++){
        first.push_back(b[i]*(mystack-Minimum) + a[i]*(1-(mystack-Minimum)));
    }
    for(int i=0;i<3;i++){
        second.push_back(b[i]*(mystack+Minimum) + a[i]*(1-(mystack+Minimum)));
    }
    return dist(second,P)-dist(first,P);

}

bool confirm_ans(vector<double> a, vector<double> b, double mystack){
    vector<double>first, second;

    for(int i=0;i<3;i++){
        first.push_back(b[i]*(mystack-Minimum) + a[i]*(1-(mystack-Minimum)));
    }
    for(int i=0;i<3;i++){
        second.push_back(b[i]*(mystack+Minimum) + a[i]*(1-(mystack+Minimum)));
    }
    cout<<"first: "<<dist(first,P)-dist(Result,P)<<endl;
    cout<<"second: "<<dist(second,P)-dist(Result,P)<<endl;
    return ((dist(first,P)-dist(Result,P))>0&&(dist(second,P)-dist(Result,P)>0));
}

float shortest_line(){

    double step ,temp, p_temp, mystack, p_mystack, back_t;

    step=Minimum;
    p_temp=dist(A,P);
    mystack=step;
    p_mystack=0;

    if(gradient(A,B,1.0f)<0){
        calc(A,B,0.0f);
        temp=dist(Result,P);
        return temp;
	}
    if(gradient(A,B,0.0f)>0){
        calc(A,B,1.0f);
        temp=dist(Result,P);
        return temp;
    }

    step=Minimum;
    p_temp=dist(A,P);
    mystack=step;
    p_mystack=0;

    for(int i=0;i<100;i++){
        calc(A,B,mystack);
        temp=dist(Result,P);
        cout<<i<<endl;
        cout<<temp<<endl;;
        cout<<"mystack: "<<mystack<<endl;
        if(mystack>1){
            temp=p_temp;
            mystack=p_mystack;
            step=Minimum;
            continue;
        }
        else if(confirm_ans(A,B,mystack)){
            return temp;
        }
        else if(gradient(A,B,mystack)>0){
            temp=p_temp;
            mystack=p_mystack;
            step=Minimum;
            continue;
        }
        p_mystack=mystack;
        mystack=mystack+step;
        step=step*2;
        p_temp=temp;
    }
}
//void f_write(){
//    list<int>::iterator iter;
//
//    fout.open("square.out");
//    if(Result.size()==0){
//        fout<<0;
//        return;
//    }
//    for(iter=Result.begin();iter!=Result.end();iter++){
//        fout<<*iter<<' ';
//    }
//}
int main(){
    f_read();
    ofstream fout;
    fout.open("connect.out");
    fout<<ceil(shortest_line());
    fout.close();

    return 0;
}
