#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;

double a[3], b[3], p[3];
int length;

void input(void){
	ifstream fin;
	fin.open("connect.inp");
	for(int i=0; i<9; i++){
		if(i<3) fin >> a[i];
		else if(i<6) fin >> b[i-3];
		else fin >> p[i-6];
	}
	fin.close();
}

void output(void){
	ofstream fout;
	fout.open("connect.out"); 
	fout << length << endl;
	fout.close();
}

int main(void) {
	input();
	double s[3];
	
	double len_ap, len_bp;
	for(int i=0; i<20; ++i){
		double suma=0, sumb=0;
		for(int j=0; j<3; ++j){
			len_ap = pow((p[j]-a[j]),2);
			len_bp = pow((p[j]-b[j]),2);
			suma += len_ap;
			sumb += len_bp;
			s[j] = 0.5*b[j] + 0.5*a[j];
		}
	
		len_ap = sqrt(suma);
		len_bp = sqrt(sumb);
	
		for(int j=0; j<3; ++j){
			if(len_ap < len_bp) b[j] = s[j];
			else if(len_ap > len_bp) a[j] = s[j];
			else i=29;
		}
	}

	double L = sqrt(pow((p[0]-s[0]),2)+pow((p[1]-s[1]),2)+pow((p[2]-s[2]),2));
	length = ceil(L); 
	
	output();
	return 0;
}
