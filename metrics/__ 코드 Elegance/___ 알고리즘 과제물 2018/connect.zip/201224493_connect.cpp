#include<iostream>
#include<vector>
#include<cmath>
#include<fstream>
int main(){std::ifstream fin;fin.open("connect.inp");int x1,y1,z1,x2,y2,z2,x3,y3,z3;fin>>x1>>y1>>z1>>x2>>y2>>z2>>x3>>y3>>z3;fin.close();double a=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)+(z1-z2)*(z1-z2));double b=sqrt((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3)+(z1-z3)*(z1-z3));double c=sqrt((x2-x3)*(x2-x3)+(y2-y3)*(y2-y3)+(z2-z3)*(z2-z3));double d=0;if(a>b&&a>c){double s=(a+b+c)/2;double S=sqrt(s*(s-a)*(s-b)*(s-c));d=(2*S)/a;}else if(b>a&&b>c){d=c;}else if(c>a&&c>b){d=b;}std::ofstream fout;fout.open("connect.out");fout<<ceil(d);fout.close();return 0;}
