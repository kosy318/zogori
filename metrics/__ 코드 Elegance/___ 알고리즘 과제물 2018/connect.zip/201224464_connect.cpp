#include<iostream>
#include<fstream>
#include<cmath>
#include<cstdlib>
using namespace std;

int main(int argc, char **argv){
	ifstream inp("connect.inp");
	ofstream out("connect.out");
	char get[100];
	double a[3], b[3], c[3];
	
	inp >> get;
	a[0] = atof(get);
	inp >> get;
	a[1] = atof(get);
	inp >> get;
	a[2] = atof(get);
	inp >> get;
	b[0] = atof(get);
	inp >> get;
	b[1] = atof(get);
	inp >> get;
	b[2] = atof(get);
	inp >> get;
	c[0] = atof(get);
	inp >> get;
	c[1] = atof(get);
	inp >> get;
	c[2] = atof(get);
	
	inp.close();
	
	double t = 0.0;
	double i = 0.1;
	
	double ab = pow(a[0]-b[0],2.0) + pow(a[1]-b[1],2.0) + pow(a[2]-b[2],2.0);
	double bc = pow(b[0]-c[0],2.0) + pow(b[1]-c[1],2.0) + pow(b[2]-c[2],2.0);
	double ac = pow(a[0]-c[0],2.0) + pow(a[1]-c[1],2.0) + pow(a[2]-c[2],2.0);

	
	if(bc <= ac){
		if(ab + bc <= ac){
			out << ceil(sqrt(bc));
		}
		else{
			while(true){
				double at[3] = {b[0]*(t+i) + (1-(t+i))*a[0], b[1]*(t+i) + (1-(t+i))*a[1], b[2]*(t+i) + (1-(t+i))*a[2]};
				double dist = pow(at[0]-c[0],2.0) + pow(at[1]-c[1],2.0) + pow(at[2]-c[2],2.0);
				
				if(i < 0.00000000001){
					int result = ceil(sqrt(pow(((at[0]+b[0])/2.0)-c[0],2.0) + pow(((at[1]+b[1])/2.0)-c[1],2.0) + pow(((at[2]+b[2])/2.0)-c[2],2.0)));
					out << result;
					break;
				}
				
				if(dist < bc){
					i *= 0.1;
				}
				else if(dist > bc){
					t = t + i;
				}
				else{
					int result = ceil(sqrt(pow(((at[0]+b[0])/2.0)-c[0],2.0) + pow(((at[1]+b[1])/2.0)-c[1],2.0) + pow(((at[2]+b[2])/2.0)-c[2],2.0)));
					out << result;
					break;
				}
			}
		}
	}
	else{	
		if(ab + ac <= bc){
			out << ceil(sqrt(ac));
		}
		else{
			while(true){
				double bt[3] = {a[0]*(t+i) + (1-(t+i))*b[0], a[1]*(t+i) + (1-(t+i))*b[1], a[2]*(t+i) + (1-(t+i))*b[2]};
				double dist = pow(bt[0]-c[0],2.0) + pow(bt[1]-c[1],2.0) + pow(bt[2]-c[2],2.0);
				if(i < 0.00000000001){
					int result = ceil(sqrt(pow(((bt[0]+a[0])/2.0)-c[0],2.0) + pow(((bt[1]+a[1])/2.0)-c[1],2.0) + pow(((bt[2]+a[2])/2.0)-c[2],2.0)));
					out << result;
					break;
				}
				
				if(dist < ac){
					i *= 0.1;
				}
				else if(dist > ac){
					t = t + i;
				}
				else{
					int result = ceil(sqrt(pow(((bt[0]+a[0])/2.0)-c[0],2.0) + pow(((bt[1]+a[1])/2.0)-c[1],2.0) + pow(((bt[2]+a[2])/2.0)-c[2],2.0)));
					out << result;
					break;
				}
			}
		}
	}
	
	out.close();
	return 0;
} 

