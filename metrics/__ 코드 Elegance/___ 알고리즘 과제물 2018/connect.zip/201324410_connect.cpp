#include <iostream>
#include <fstream>
#include <math.h>
using namespace std;
struct point {
	double x;
	double y;
	double z;
};
int finish;
point Start, End, Random;
int mino = 20000000;

void inp() {
	ifstream fin;
	fin.open("connect.inp");
	fin >> Start.x >> Start.y >> Start.z;
	fin >> End.x >> End.y >> End.z;
	fin >> Random.x >> Random.y >> Random.z;

}

void output() {
	
	ofstream fout;
	fout.open("connect.out");
	fout << mino;
	fout.close();

}

void processing() {
	double t = 0;
	int counter;
	double compare_start = 0.5;
	point temp;
		
		while (t < 1) {
			t = t + 0.001;
			temp.x = t* Start.x + (1 - t)*End.x;
			temp.y = t* Start.y + (1 - t)*End.y;
			temp.z = t* Start.z + (1 - t)*End.z;
			counter = ceil(sqrt(pow((Random.x - temp.x), 2) + pow((Random.y - temp.y), 2) + pow((Random.z - temp.z), 2)));
			if (counter < mino) {
				mino = counter;
			}
			else if (counter > mino) {
				break;
			}
		}
	
}

int main() {

	inp();
	processing();
	output();
	return 0;
}