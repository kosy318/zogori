#include <iostream>
#include <math.h>
#include <stdio.h>
#include <cfloat>
#define epsilon LDBL_EPSILON
#include <fstream>
using namespace std;
bool essentiallyEqual(double a, double b)
{
    return fabs(a - b) < epsilon;
}

bool GreaterThan(double a, double b)
{
    return (a - b) > ( (fabs(a) < fabs(b) ? fabs(b) : fabs(a)) * epsilon);
}

bool LessThan(double a, double b)
{
    return (b - a) > ( (fabs(a) < fabs(b) ? fabs(b) : fabs(a)) * epsilon);
}

int main()
{
    ifstream fin;
    ofstream fout;

    fin.open("connect.inp");
    fout.open("connect.out");

    struct Point{
        double x,y,z;
    } A, B, P, S;

    double dist = 0;

    fin >> A.x >> A.y >> A.z >> B.x >> B.y >> B.z >> P.x >> P.y >> P.z;

    S.x = (0.5)*(A.x + B.x);
    S.y = (0.5)*(A.y + B.y);
    S.z = (0.5)*(A.z + B.z);

    int i;
    for(i=0; i< 500; ++i){
        double AtoP = sqrt(pow(A.x-P.x,2)+pow(A.y-P.y,2)+pow(A.z-P.z,2));
        double BtoP = sqrt(pow(B.x-P.x,2)+pow(B.y-P.y,2)+pow(B.z-P.z,2));

        if(GreaterThan(AtoP, BtoP)){
            A = S;

            S.x = (A.x + B.x) * 0.5;
            S.y = (double)0.5* (A.y + B.y);
            S.z = (double)0.5* (A.z + B.z);

        }
        else if(LessThan(AtoP, BtoP)){
            B = S;
            S.x = (double)(0.5)*(A.x + B.x);
            S.y = (double)(0.5)*(A.y + B.y);
            S.z = (double)(0.5)*(A.z + B.z);
        }
        else if (essentiallyEqual(AtoP, BtoP)) {
            break;
        }
        else
            continue;
    }
    dist = ceil( sqrt( pow(S.x - P.x, 2) + pow(S.y - P.y,2) + pow(S.z-P.z,2)) );
    fout << dist << endl;

    fin.close();
    fout.close();
    return 0;
}
