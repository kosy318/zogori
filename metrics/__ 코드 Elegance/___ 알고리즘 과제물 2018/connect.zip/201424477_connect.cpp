#include <iostream>
#include <fstream>
#include<math.h>
using namespace std;

int main() {
	int Ax, Ay, Az;
	int Bx, By, Bz;
	int Px, Py, Pz;

	ifstream inf("connect.inp"); 
	ofstream ouf("connect.out");

	inf >> Ax;
	inf >> Ay;
	inf >> Az;
	inf >> Bx;
	inf >> By;
	inf >> Bz;
	inf >> Px;
	inf >> Py;
	inf >> Pz;

	cout << "A:" << Ax << " " << Ay << " " << Az << endl;
	cout << "B:" << Bx << " " << By << " " << Bz << endl;
	cout << "A:" << Px << " " << Py << " " << Pz << endl;

	
	//xiangliang AB
	int ABx = Bx - Ax;
	int ABy = By - Ay;
	int ABz = Bz - Az;
	//xiangliang AP
	int APx = Px - Ax;
	int APy = Py - Ay;
	int APz = Pz - Az;
	//xiangliang BA
	int BAx = Ax - Bx;
	int BAy = Ay - By;
	int BAz = Az - Bz;
	//xiangliang BP
	int BPx = Px - Bx;
	int BPy = Py - By;
	int BPz = Pz - Bz;

	double Distance = 0.000;
	float min = 10000000000.000;
	float Dx, Dy, Dz;
	if ((Ax >= -1000 && Ax <= 1000) && (Ay >= -1000 && Ay <= 1000) && (Az >= -1000 && Az <= 1000) &&
		(Bx >= -1000 && Bx <= 1000) && (By >= -1000 && By <= 1000) && (Bz >= -1000 && Bz <= 1000) &&
		(Px >= -1000 && Px <= 1000) && (Py >= -1000 && Py <= 1000) && (Pz >= -1000 && Pz <= 1000))
	{
		if (ABx*APx + ABy*APy + ABz*APz <= 0) {
			Distance = sqrt((Ax - Px)*(Ax - Px) + (Ay - Py)*(Ay - Py) + (Az - Pz)*(Az - Pz));
			
		}
		else if (BAx*BPx + BAy*BPy + BAz*BPz <= 0) {
			Distance = sqrt((Bx - Px)*(Bx - Px) + (By - Py)*(By - Py) + (Bz - Pz)*(Bz - Pz));
			
		}
		
		
		else {
			for (float t = 0.00; t < 1.00; t = t + 0.001) {
				Dx = t*Bx + (1 - t)*Ax;
				Dy = t*By + (1 - t)*Ay;
				Dz = t*Bz + (1 - t)*Az;
				double Dis =  sqrt((Dx - Px)*(Dx - Px) + (Dy - Py)*(Dy - Py) + (Dz - Pz)*(Dz - Pz));
				if (min > Dis) {
					min = Dis;
				}
			}
			Distance = min;
			
		}
		
	}


	cout << ceil(Distance);

	ouf << ceil(Distance);
	ouf.close();
	inf.close();

	
	return 0;
}