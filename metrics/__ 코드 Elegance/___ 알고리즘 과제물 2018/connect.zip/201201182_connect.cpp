#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

double getDist(double* str,double* dest)
{
	double x = dest[0] - str[0];
	double y = dest[1] - str[1];
	double z = dest[2] - str[2];

	return sqrt(x*x + y*y + z*z);
}
double solve(double* start, double* end, double* target)
{
	double d = getDist(start, end);
	
	double sDist = getDist(start, target);
	double eDist = getDist(end, target);

	if (d < 1)
		return sDist < eDist ? sDist : eDist;

	double mid[3];
	for (int i = 0; i < 3; i++)
		mid[i] = (start[i] + end[i]) / 2;

	if (sDist > eDist)
		return solve(mid, end, target);
	else if (eDist > sDist)
		return solve(start, mid, target);
	else
		return getDist(mid, target);
}

int main()
{
	double a[3],b[3],p[3];

	ifstream ifs("connect.inp");
	ofstream ofs("connect.out");

	ifs >> a[0] >> a[1] >> a[2];
	ifs >> b[0] >> b[1] >> b[2];
	ifs >> p[0] >> p[1] >> p[2];

	double d = solve(a, b, p);
	
	ofs << ceil(d) << endl;

	ifs.close();
	ofs.close();
	return 0;
}