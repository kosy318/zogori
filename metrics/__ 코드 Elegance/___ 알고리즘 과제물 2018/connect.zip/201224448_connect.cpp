#include<stdio.h>
#include<math.h>
void cal_vector(int X[], int Y[], int Z[]) {
    int i;
    for (i = 0; i<3; i++) {
        Z[i] = Y[i] - X[i];
    }
}
int main(void) {
    int A[3] = { 0,0,0 }, B[3] = { 0,0,0 }, P[3] = { 0,0,0 },
            AB[3] = { 0,0,0 }, AP[3] = { 0,0,0 }, BP[3] = { 0,0,0 }, i;
    float result1 = 0, result2 = 0, t = 0, distance = 0;

    FILE *fpin, *fpout;
    fpin = fopen("connect.inp", "r");
    fpout = fopen("connect.out", "w");
    if (fpin == NULL) {
        printf("FILE OPEN ERROR! \n");
        return -1;
    }

    fscanf(fpin, "%d %d %d", &A[0], &A[1], &A[2]);
    fscanf(fpin, "%d %d %d", &B[0], &B[1], &B[2]);
    fscanf(fpin, "%d %d %d", &P[0], &P[1], &P[2]);
    for (i = 0; i < 3; i++) { //¡° A,B,P¿« π¸¡÷∏¶ π˛æÓ≥≠ ∞ÊøÏ
        if (A[i] >= 1000 || A[i] <= -1000) return 1;
        if (B[i] >= 1000 || B[i] <= -1000) return 1;
        if (P[i] >= 1000 || P[i] <= -1000) return 1;
    }
    cal_vector(A, B, AB);
    cal_vector(A, P, AP);
    cal_vector(B, P, BP);

    for (i = 0; i < 3; i++) {
        result1 += AB[i] * AP[i];
        result2 += AB[i] * AB[i];
    }
    if (result2 == 0) return 1;
    t = result1 / result2;

    if (t <= 0) {
        for (i = 0; i < 3; i++) {
            distance += AP[i] * AP[i];
        }
        distance = sqrt(distance);
        //printf("%d\n//%.4f", (int)ceil(distance), distance);
    }

    else if (t >= 1) {
        for (i = 0; i < 3; i++) {
            distance += BP[i] * BP[i];
        }
        distance = sqrt(distance);
        //printf("%d\n//%.4f", (int)ceil(distance), distance);
    }
    else {
        for (i = 0; i < 3; i++) {
            distance += (-t*(float)AB[i] + (float)A[i] - P[i])*(t*(float)AB[i] + (float)A[i] - P[i]);
        }
        distance = sqrt(distance);
        //printf("%d\n//%.4f\n", (int)ceil(distance), distance);
    }
    fprintf(fpout,"%d",(int)ceil(distance));
    fclose(fpin);
    fclose(fpout);
    return 0;
}