#include<iostream>
#include<fstream>
#include<cmath>
using namespace std;
int Ax, Ay, Az, Bx, By, Bz, Px, Py, Pz;

double getDistance(float t) {
	float Tx, Ty, Tz;
	Tx = (1 - t)*Ax + t*Bx;
	Ty = (1 - t)*Ay + t*By;
	Tz = (1 - t)*Az + t*Bz;
	return sqrt(pow(Tx - Px, 2.0) + pow(Ty - Py, 2.0) + pow(Tz - Pz, 2.0));
}

float gradiant(float t) {
	return getDistance(t + 0.0001) - getDistance(t);
}


int main() {
	ifstream inFile("connect.inp");
	ofstream outFile("connect.out");
	float lowMark, highMark, middleMark;

	inFile >> Ax >> Ay >> Az >> Bx >> By >> Bz >> Px >> Py >> Pz;
	lowMark = 0;
	highMark = 1;
	while (1) {
		if (highMark - lowMark < 0.0002) {
			outFile << ceil(getDistance(highMark));
			break;
		}
		middleMark = (lowMark + highMark) / 2;
	
		if (gradiant(middleMark) < 0) {
			lowMark = middleMark;
		}
		else {
			highMark = middleMark;
		}
	}

	inFile.close();
	outFile.close();
	//system("pause");
	return 0;
}