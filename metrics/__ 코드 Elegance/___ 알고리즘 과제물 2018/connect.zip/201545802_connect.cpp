#include <cmath>
#include <limits>
#include <cassert>

#include <fstream>
#include <sstream>
#include <tuple>
using namespace std;
struct Point;
using Points3 = tuple<Point, Point, Point>;
#define SQUARE(x)   ((x)*(x))

//===============================================================
int             ceil_toint(double x)
{
    return (int)ceil(x);
}
//---------------------------------------------------------------

//---------------------------------------------------------------
enum            NumKind
{
    ORDINARY_NUM,
    INFINITE_NUM,
    NOT_A_NUM,
};

NumKind         kind(double x)
{
    return
        std::isinf(x) ?
        INFINITE_NUM
        : std::isfinite(x) ?
        ORDINARY_NUM
        : NOT_A_NUM;
}

inline
bool            two_nan_one_ordinary(double x, double y, double z)
{
    return
        (kind(x) == NOT_A_NUM    && kind(y) == NOT_A_NUM    && kind(z) == ORDINARY_NUM) ||
        (kind(x) == NOT_A_NUM    && kind(y) == ORDINARY_NUM && kind(z) == NOT_A_NUM) ||
        (kind(x) == ORDINARY_NUM && kind(y) == NOT_A_NUM    && kind(z) == NOT_A_NUM);
}

inline
bool            nan_ord_ord(double x, double y, double z)
{
    return
        (kind(x) == NOT_A_NUM    &&
            kind(y) == ORDINARY_NUM &&
            kind(z) == ORDINARY_NUM);
}

inline
bool            ord_nan_ord(double x, double y, double z)
{
    return
        (kind(x) == ORDINARY_NUM &&
            kind(y) == NOT_A_NUM    &&
            kind(z) == ORDINARY_NUM);
}

inline
bool            ord_ord_nan(double x, double y, double z)
{
    return
        (kind(x) == ORDINARY_NUM &&
            kind(y) == ORDINARY_NUM &&
            kind(z) == NOT_A_NUM);
}
//---------------------------------------------------------------

//---------------------------------------------------------------
struct          Point
{
    const int   X;
    const int   Y;
    const int   Z;
    Point(int x, int y, int z)
        :X(x), Y(y), Z(z)
    {}
};

bool            operator == (const Point& A, const Point& B)
{
    return (A.X == B.X && A.Y == B.Y && A.Z == A.Z);
}
//---------------------------------------------------------------

//---------------------------------------------------------------
struct          Vector
{
    const Point A;
    const Point B;
    const int   x, y, z;
    const double len_square;
    const double len;

    Vector(const Point& a, const Point& b) // make vetor: A->B
        :A(a), B(b),
        x(b.X - a.X), y(b.Y - a.Y), z(b.Z - a.Z),
        len_square(x*x + y*y + z*z), len(sqrt(len_square))
    {}
};

bool            are_parallel(const Vector& a, const Vector& b)
{
    if(a.x == 0 && a.y == 0 && a.z == 0 &&
        b.x == 0 && b.y == 0 && b.z == 0)
    {
        assert(!"(0,0,0) (0,0,0) comparison!");
    }

    double  x_ratio = (double)a.x / (double)b.x;
    double  y_ratio = (double)a.y / (double)b.y;
    double  z_ratio = (double)a.z / (double)b.z;

    // (N o o), (o N o), (o o N).
    if(two_nan_one_ordinary(x_ratio, y_ratio, z_ratio)) {
        return true;
    } else if(nan_ord_ord(x_ratio, y_ratio, z_ratio))
    {     // N   o   o
        return (y_ratio == z_ratio) ? true : false;
    } else if(ord_nan_ord(x_ratio, y_ratio, z_ratio))
    {     // o   N   o
        return (x_ratio == z_ratio) ? true : false;
    } else if(ord_ord_nan(x_ratio, y_ratio, z_ratio))
    {     // o   o   N
        return (x_ratio == y_ratio) ? true : false;
    } else if(x_ratio == INFINITE_NUM ||
        y_ratio == INFINITE_NUM ||
        z_ratio == INFINITE_NUM)
    {
        return false;
    } else if(x_ratio == y_ratio && y_ratio == z_ratio)
    {
        return true;
    } else { // a,b are ordinarily not parallel. no NaN and no infinity!
        return false;
    }
}
int             operator * (const Vector& a, const Vector& b)
{
    return (a.x * b.x + a.y * b.y + a.z * b.z);
}
//---------------------------------------------------------------

//---------------------------------------------------------------
enum AngleKind {
    ACUTE_ANGLE,
    RIGHT_ANGLE,
    OBTUSE_ANGLE,
};

AngleKind       angle_between(const Vector& a, const Vector& b)
{
    int inner_prod = a*b;
    if(inner_prod > 0) {
        return ACUTE_ANGLE;
    } else if(inner_prod < 0) {
        return OBTUSE_ANGLE;
    } else {
        return RIGHT_ANGLE;
    }
}

int             min_distance(const Vector& a, const Point& P)
{
    Vector      p(a.A, P);
    Vector      x(a.B, P);
    AngleKind   a_p_angle = angle_between(a, p);
    AngleKind   a_x_angle = angle_between(a, x);

    double distance;
    if(are_parallel(x, p)) {
        double ratio = (double)p.x / (double)a.x;
        if(1.0 < ratio) {
            distance = x.len;
        } else if(0.0 < ratio && ratio < 1.0) { // A--P--B
            distance = 0.0;
        } else if(ratio < 0.0) {
            distance = p.len;
        }
    } else if(a_p_angle == ACUTE_ANGLE && a_x_angle == ACUTE_ANGLE) {
        distance = x.len;
        //std::cout << 1;
    } else if(a_p_angle == ACUTE_ANGLE && a_x_angle == OBTUSE_ANGLE) {
        distance = std::sqrt(p.len_square - SQUARE((double)(a*p)) / a.len_square);
        //std::cout << 2;
    } else if(a_p_angle == ACUTE_ANGLE && a_x_angle == RIGHT_ANGLE) {
        distance = x.len;
        //std::cout << 3;
    } else if(a_p_angle == RIGHT_ANGLE && a_x_angle == OBTUSE_ANGLE) {
        distance = p.len;
        //std::cout << 4;
    } else if(a_p_angle == OBTUSE_ANGLE && a_x_angle == OBTUSE_ANGLE) {
        distance = p.len;
        //std::cout << 5;
    } else {
        assert("what??");
    }
    return ceil_toint(distance);
}
//---------------------------------------------------------------

//---------------------------------------------------------------
Points3         read_from(istream& input)
{
    int x, y, z;
    input >> x >> y >> z; Point X(x, y, z);
    input >> x >> y >> z; Point Y(x, y, z);
    input >> x >> y >> z; Point Z(x, y, z);
    return Points3(X, Y, Z);
}

void            write_to(ostream& output_stream, int output)
{
    output_stream << output;
}
//===============================================================

int main(void) {
    ifstream    ifs("connect.inp");
    auto        points  = read_from(ifs);
    ifs.close();

    Point       A       = get<0>(points);
    Point       B       = get<1>(points);
    Point       P       = get<2>(points);
    Vector      AB(A,B);

    int         result  = min_distance(AB, P);

    ofstream    ofs("connect.out");
    write_to(ofs, result);
    ofs.close();
    return 0;
}