#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

#define TESTCASE  (50)       /* �׽�Ʈ ���̽� ���� */

int A1, B1, C1, P1, Q1, R1;  /* ����1�� �� ���� */
int X, Y, Z;

int Answer;                  /* ����: �ּҵѷ����� ū �ּ��� ���� */
ifstream rf("connect.inp");
ofstream wf("connect.out");

/* Compute the absolute value of x */
double m_abs( double x ) {
	return x<0?-x:x;
}

/* Compute the square root of x */
double m_sqrt( double x ) {
	return sqrt(x);
}

/* Compute the distance between points (x,y,z) and (p,q,r) */
double dist( double x, double y, double z, double p, double q, double r ) {
	double dx = x - p;
	double dy = y - q;
	double dz = z - r;
	return m_sqrt( dx*dx + dy*dy + dz*dz );
}

/* Compute the distance between points (1-alpha)(x,y,z)+ (alpha)(p,q,r) and (a,b,c) */
double dist_alpha( double x, double y, double z, double p, double q, double r, double alpha, double a, double b, double c ) {
	double alphax = (1-alpha)*x + alpha*p;
	double alphay = (1-alpha)*y + alpha*q;
	double alphaz = (1-alpha)*z + alpha*r;

	double dx = alphax - a;
	double dy = alphay - b;
	double dz = alphaz - c;
	return m_sqrt( dx*dx + dy*dy + dz*dz );
}

/* Compute the minimum of the sum of the distances from a point on segment (x1,y1,z1)-(x2,y2,z2) to two points (xp, yp, zp) and (xq, yq, zq) */
double get_min_point_binary( double x1, double y1, double z1, double x2, double y2, double z2, double xp, double yp, double zp, double epsilon ) {
	double ss = 0;
	double tt = 1;

	while( tt - ss > epsilon ) {

		double mid = (ss+tt)/2;
		double alpha = (ss+mid)/2;
		double beta  = (mid+tt)/2;

		double dap = dist_alpha( x1, y1, z1, x2, y2, z2, alpha, xp, yp, zp );
		double dmp = dist_alpha( x1, y1, z1, x2, y2, z2, mid  , xp, yp, zp );
		double dbp = dist_alpha( x1, y1, z1, x2, y2, z2, beta , xp, yp, zp );

		double da = dap;
		double dm = dmp;
		double db = dbp;

		if( dm <= da && dm <= db ) {
			ss = alpha;
			tt = beta;
			continue;
		}
		if( da <= dm && da <= db ) {
			tt = mid;
			continue;
		}
		if( db <= dm && db <= da ) {
			ss = mid;
			continue;
		}
	}
	return (ss+tt)/2;
}

/* Compute ceiling(x+epsilon) */
int m_ceil( double x ) {
	return x+0.999999;
}


double solve( void ) {
        double p[3], q[3];
	double x[3];
        double a = 0.5;

	p[0] = A1; p[1] = B1; p[2] = C1; q[0] = P1; q[1] = Q1; q[2] = R1;
	x[0] = X; x[1] = Y; x[2] = Z;

        while( 1 ) {
                double x1 = p[ 0 ];
                double y1 = p[ 1 ];
                double z1 = p[ 2 ];
                double x2 = q[ 0 ];
                double y2 = q[ 1 ];
                double z2 = q[ 2 ];

                double xp = x[ 0 ];
                double yp = x[ 1 ];
                double zp = x[ 2 ];

                double new_a = get_min_point_binary( x1, y1, z1, x2, y2, z2, xp, yp, zp, 0.00001 );

                double old_d = dist_alpha( x1, y1, z1, x2, y2, z2, a , xp, yp, zp );
                double new_d = dist_alpha( x1, y1, z1, x2, y2, z2, new_a, xp, yp, zp );
		double diff_d = old_d - new_d;

                if( diff_d > 0.00001 ) {
			a = new_a;
		} else {
			break;
		}
        }
        double min_d;
        {
                double x0 = (1-a) * p[0] + (a) * q[0];
                double y0 = (1-a) * p[1] + (a) * q[1];
                double z0 = (1-a) * p[2] + (a) * q[2];
                double x1 = x[0];
                double y1 = x[1];
                double z1 = x[2];

                double d01 = dist( x0, y0, z0, x1, y1, z1 );

                min_d = d01;
        }

        //cout << min_d << '\t' << a << '\t' << m_ceil( min_d ) << endl;
        Answer = m_ceil( min_d );
        return min_d;
}

int main(void) {
	int t;

    /* *******************************************************************************************
     ǥ���Է��� ���� �� ������ ���� ��ǥ���� �н��ϴ�.
     �� ������ ��ǥ��
        (A1, B1, C1), (P1, Q1, R1)
        (A2, B2, C2), (P2, Q2, R2)
        (A3, B3, C3), (P3, Q3, R3)
     �� ����˴ϴ�.
    ******************************************************************************************* */
    rf >> A1 >> B1 >> C1 >> P1 >> Q1 >> R1;
    rf >> X >> Y >> Z;

    solve();
    wf << Answer << endl;

	rf.close();
	wf.close();
	return 0;
}
