#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>
using namespace std;

void LoadOnePoint(vector<double>* point){
    ifstream inFile("connect.inp");
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++) {
            double temp_num;
            inFile>> temp_num;
            point[i].push_back(temp_num);
        }
        point[3].push_back(0.0);
    }
    inFile.close();
}

void SaveFile(int result){
    ofstream outFile("connect.out");
    outFile<<result;
    outFile.close();
}

double Distance(vector<double> A,vector<double> B){
    double result=0;
    for(int i=0;i<3;i++){
        result+=(A[i]-B[i])*(A[i]-B[i]);
    }
    //cout<<result<<" "<< sqrt(result)<<endl;
    return sqrt(result);
}

double Square(double number){
    return number*number;
}

void MiddlePoint(vector<double>* point){
    for(int i=0; i<3 ;i++){
       // cout<<point[0][i]<<" "<<point[1][i]<<endl;
        point[3][i]=(point[0][i]+point[1][i])*0.5;
    }
}

int CompareDistance(double distanceA,double distanceB){
    if(distanceA == distanceB) return 2;
    return distanceA < distanceB;
}

void SwitchPoint(vector<double>& A,vector<double>& B){
    for(int i=0;i<3;i++){
        A[i]=B[i];
    }
}

double CalculateResult(vector<double>* point){
    double distanceA = Distance(point[0],point[2]);
    double distanceB = Distance(point[1],point[2]);
    int compareResult=CompareDistance(distanceA,distanceB);
    //cout<<compareResult<<endl;
    MiddlePoint(point);
    //cout<<point[3][1]<<" "<<point[3][1]<<" "<<point[3][2]<<" "<<endl;
    if(compareResult==2 ) return Distance(point[2],point[3]);
    else SwitchPoint(point[compareResult],point[3]);
    CalculateResult(point);
}


int main()
{
    vector<double> point[4];
    double result;
    LoadOnePoint(point);
    result=CalculateResult(point);
    SaveFile((int)ceil(result));

    //cout << (int)ceil(result) << endl;
    return 0;
}
