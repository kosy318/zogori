#include <stdio.h>
#include <math.h>
#define	ABS(x)	((x)<0)? -(x):(x)
struct location{
    double x;
    double y;
    double z;
};
double Square_Distance(location A, location B);
void ReadFile(FILE *r, location *a, location *b, location *p);
location Set_Location(location A, location B, double t);
double Min_Dist(location A, location B, location P);
double Rec_Dist(location A, location B, location P, location temp);
int main(){
    FILE *rFile = NULL;
    rFile = fopen("connect.inp", "r");
    FILE *wFile = NULL;
    wFile = fopen("connect.out", "w");
    location A,B,P;
    double result;
    ReadFile(rFile, &A, &B, &P);
    result = Rec_Dist(A,B,P,Set_Location(A,B,0.5));
    fprintf(wFile, "%0.lf", ceil(sqrt(result)));

    fclose(wFile);
}

double Square_Distance(location A, location B){
    double result = (A.x - B.x)*(A.x - B.x) + (A.y - B.y)*(A.y - B.y) + (A.z - B.z)*(A.z - B.z);
    return result;
}

void ReadFile(FILE *r, location *a, location *b, location *p){
    if(r == NULL){
        printf("file is not exist\n");
    }
    else{
        fscanf(r, "%lf %lf %lf\n",&a->x,&a->y,&a->z);
        fscanf(r, "%lf %lf %lf\n",&b->x,&b->y,&b->z);
        fscanf(r, "%lf %lf %lf\n",&p->x,&p->y,&p->z);
    }
    fclose(r);
}

location Set_Location(location A, location B, double t){
    location result;
    result.x = B.x*t + A.x*(1-t);
    result.y = B.y*t + A.y*(1-t);
    result.z = B.z*t + A.z*(1-t);
    return result;
}

double Min_Dist(location A, location B, location P){
    double t = 0.5;
    location set_location = Set_Location(A, B, t);
    double dist_1 = Square_Distance(A,P);
    double dist_2 = Square_Distance(B,P);
    double dist_result = Square_Distance(P, set_location);
    while(1){
        if (dist_1 > dist_2){
            t = 1.5*t ;
            set_location = Set_Location(A, B, t);
            if (Square_Distance(P, set_location) <= dist_result){
                dist_1 = dist_result;
                dist_result = Square_Distance(P, set_location);
            }
            else{
                break;
            }
        }
        else {
            t = 0.5*t ;
            set_location = Set_Location(A, B, t);
            if (Square_Distance(P, set_location) <= dist_result){
                dist_2 = dist_result;
                dist_result = Square_Distance(P, set_location);
            }
            else{
                break;
            }
        }
    }

    return dist_result;
}

double Rec_Dist(location A, location B, location P, location temp){
    double result;
    if(Square_Distance(A,P) == Square_Distance(B,P)){
        result = Square_Distance(P, temp);
        return result;
    }
    else if(Square_Distance(A,P) > Square_Distance(B,P)){
        return Rec_Dist(temp, B, P, Set_Location(temp, B, 0.5));
    }
    else{
        return Rec_Dist(A, temp, P, Set_Location(A, temp, 0.5));
    }
}

