#include <stdio.h>
#include <math.h>

struct point {
	float value[3];
};

struct point outPoint;

struct point calCenter(struct point a, struct point b) {
	int i;
	struct point res;
	for (i = 0; i < 3; i++)
		res.value[i] = (a.value[i] + b.value[i]) / 2;
	return res;
}

int length(struct point a, struct point b) {
	double res =0 ;
	int i;
	for (i = 0; i < 3; i++)
		res += (a.value[i] - b.value[i]) *(a.value[i] - b.value[i]);
	return (int)ceil(sqrt(res));
}


int main(int argc, char **argv) {
	FILE *in, *out;
	int i, j, k;
	long long len[3];
	struct point outPoint, linePoint[2], centerPoint;
	in = fopen("connect.inp", "r");
	out = fopen("connect.out", "w");

	for (i = 0; i < 2; i++)
		for (j = 0; j < 3; j++)
			fscanf(in, "%f", &linePoint[i].value[j]);
	for (i = 0; i < 3; i++)
		fscanf(in, "%f", &outPoint.value[i]);

	while (1) {
		centerPoint = calCenter(linePoint[0], linePoint[1]);
		len[0] = length(linePoint[0], outPoint);
		len[1] = length(linePoint[1], outPoint);
		
		if (len[0] < len[1])
			linePoint[1] = centerPoint;
		else if (len[0] > len[1])
			linePoint[0] = centerPoint;
		else {
			len[2] = length(centerPoint, outPoint);
			fprintf(out, "%d", len[2]);
			break;
		}
	}

	fclose(in);
	fclose(out);
	return 0;
}