#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
#include <fstream>
using namespace std;
double A[3];
double B[3];
double P[3];
double S[3]; //������ ��
double S0[3]; //������ ������ ������
double dist1,dist2;
bool decision(double t)
{
    double t0 = t - 0.00001;
    for(int i = 0; i < 3; ++i){
        S0[i] = t0*B[i] + (1-t0)*A[i];
    }
    for(int i = 0; i < 3; ++i){
        S[i] = t*B[i] + (1-t)*A[i];
    }
    dist1 = sqrt((S0[0]-P[0])*(S0[0]-P[0])+(S0[1]-P[1])*(S0[1]-P[1])+(S0[2]-P[2])*(S0[2]-P[2]));
    dist2 = sqrt((S[0]-P[0])*(S[0]-P[0])+(S[1]-P[1])*(S[1]-P[1])+(S[2]-P[2])*(S[2]-P[2]));
    printf("%f %f\n",dist1,dist2);
    if(dist1>dist2)
        return true;
    else
        return false;
}
double Near(void)
{
    double low = 0, high = 1;
    for(int i = 0; i < 50; ++i){
        double mid = (low + high) / 2.0;
        if(decision(mid))
            low = mid;
        else
            high = mid;
    }
    return dist1;
}
int main(void)
{
    ifstream fin;
    ofstream fout;
    fin.open("connect.inp");
    int result;
    double re;
    for(int i = 0; i < 3; ++i){
        fin >> A[i];
    }
    for(int i = 0; i < 3; ++i){
        fin >> B[i];
    }
    for(int i = 0; i < 3; ++i){
        fin >> P[i];
    }
    re = Near();
    result = int(re)+1;
    fout.open("connect.out");
    fout << result;
    fin.close();
    fout.close();
    return 0;
}
