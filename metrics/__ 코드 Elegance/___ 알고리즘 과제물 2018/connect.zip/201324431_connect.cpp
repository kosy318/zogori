#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>

using namespace std;

//A,B,P point
vector <double> A_Point;
vector <double> B_Point;
vector <double> P_Point;

//result integer value
int minResultInteger;

//input function
void readFileAndPointIn() {
	double tempNum;

	for(int i = 0; i < 3; i ++) {
		cin >> tempNum;

		A_Point.push_back(tempNum);
	}

	for(int i = 0; i < 3; i ++) {
		cin >> tempNum;

		B_Point.push_back(tempNum);
	}

	for(int i = 0; i < 3; i ++) {
		cin >> tempNum;

		P_Point.push_back(tempNum);
	}

}

//calculate length between P point and S point on S
double calculLength(double t_value) {
    vector <double> S_Point;
    double tempNum, lengthNum;

    for(int i = 0; i < 3; i ++) {
        tempNum = t_value * B_Point[i] + (1 - t_value) * A_Point[i];

		S_Point.push_back(tempNum);
	}

	lengthNum = sqrt(pow(S_Point[0] - P_Point[0], 2) + pow(S_Point[1] - P_Point[1], 2) + pow(S_Point[2] - P_Point[2], 2));

	return lengthNum;
}

//check end function -- if this function true, loop end
bool checkEnd(double firstLength, double secondLength, double midLength) {
    bool loopIsEnd = false;

    //if first, second and mid length's integer part same, loop end
    int checkPoint = floor(midLength);
    if(checkPoint == floor(firstLength) && checkPoint == floor(secondLength)) {
        loopIsEnd = true;
    }

    return loopIsEnd;
}

//doing loop function -- main algorithm
void findMinLengthLoop(double first_t_value, double second_t_value) {
    double firstLength = calculLength(first_t_value);
    double secondLength = calculLength(second_t_value);
    double midLength = calculLength((first_t_value + second_t_value) / 2.0);

    double minLength = (((firstLength < secondLength) ? firstLength : secondLength) < midLength) ? midLength : ((firstLength < secondLength) ? firstLength : secondLength);

    if(checkEnd(firstLength, secondLength, midLength)) {
        minResultInteger = ceil(minLength);
    } else {
        double new_t_value = ((firstLength < secondLength) ? first_t_value : second_t_value);
        findMinLengthLoop(new_t_value, (first_t_value + second_t_value) / 2.0);
    }
}

void findMinLengthStart() {
    if(calculLength(0) == 0 || calculLength(1) == 0) {
        minResultInteger = 0;
    } else {

        findMinLengthLoop(0.0, 1.0);
    }


}

//output function
void outMinLengthResult() {
	ofstream outputFile;

	outputFile.open("connect.out");

    outputFile << minResultInteger;

	outputFile.close();
}

//main function
int main(int argc, char** argv) {

	freopen("connect.inp", "r", stdin);

	readFileAndPointIn();

	findMinLengthStart();

	outMinLengthResult();

	return 0;
}
