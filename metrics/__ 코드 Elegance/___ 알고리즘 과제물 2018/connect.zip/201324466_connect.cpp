#include <iostream>
#include <fstream>
#include <math.h>
using namespace std;

void mid(double x[], double y[], double z[]) {
	for (int i = 0; i < 3; i++) {
		z[i] = (x[i] + y[i]) / 2;
	}
}

double distance(double x[], int y[]) {
	double sum = 0;
	for (int i = 0; i < 3; i++) {
		sum += (x[i] - y[i])*(x[i] - y[i]);
	}
	
	return sqrt(sum);
}

int main() {
	ifstream in("connect.inp");
	ofstream out("connect.out");

	double A[3], B[3];
	int P[3];
	double min;

	for (int i = 0; i < 9; i++) {
		if (i / 3 == 0)
			in >> A[i];
		else if (i / 3 == 1)
			in >> B[i % 3];
		else
			in >> P[i % 3];
	}

	while (distance(A, P) != distance(B, P)) {
		if (distance(A, P) > distance(B, P)) {
			mid(A, B, A);
		}

		else {
			mid(A, B, B);
		}
	}
	min = distance(A, P);

	int a = min;

	if (a == min)
		out << a << endl;
	else
		out << a + 1 << endl;
}