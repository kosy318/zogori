#include <fstream>
#include <math.h>
using namespace std;

int main()
{
	double Ax, Ay, Az, Bx, By, Bz, Px, Py, Pz;
	double d;
	double longLen, shortLen;
	double dAB, dPB, dPA;
	double r[3] = { 0, };
	double u[3] = { 0, };
	double AP[3] = { 0, };
	double BP[3] = { 0, };
	ifstream fin("connect.inp");
	ofstream fout("connect.out");
	
	fin >> Ax >> Ay >> Az;
	fin >> Bx >> By >> Bz;
	fin >> Px >> Py >> Pz;

	u[0] = Bx - Ax;
	u[1] = By - Ay;
	u[2] = Bz - Az;
	
	AP[0] = Px - Ax;
	AP[1] = Py - Ay;
	AP[2] = Pz - Az;

	BP[0] = Px - Bx;
	BP[1] = Py - By;
	BP[2] = Pz - Bz;

	r[0] = AP[1] * u[2] - AP[2] * u[1];
	r[1] = AP[2] * u[0] - AP[0] * u[2];
	r[2] = AP[0] * u[1] - AP[1] * u[0];

	d = (pow(r[0], 2) + pow(r[1], 2) + pow(r[2], 2))/
		(pow(u[0], 2) + pow(u[1], 2) + pow(u[2], 2));

	dAB = (pow(u[0], 2) + pow(u[1], 2) + pow(u[2], 2));

	dPB = (pow(BP[0], 2) + pow(BP[1], 2) + pow(BP[2], 2));
	dPA = (pow(AP[0], 2) + pow(AP[1], 2) + pow(AP[2], 2));

	
	if (dPA > dPB)
	{
		longLen = dPA;
		shortLen = dPB;
	}
	else
	{
		longLen = dPB;
		shortLen = dPA;
	}

	if ((longLen - d) > dAB)
		fout << ceil(sqrt(shortLen));
	else
		fout << ceil(sqrt(d));

	fin.close();
	fout.close();
}