#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

class point {
public:
	double x;
	double y;
	double z;
};

double power(double e) {
	return e * e;
}

double distance(point a, point b) {
	return sqrt(power(b.x - a.x) + power(b.y - a.y) + power(b.z - a.z));
}

point parametric(point a, point b, double t) {
	point s;
	s.x = t * b.x + (1 - t) * a.x;
	s.y = t * b.y + (1 - t) * a.y;
	s.z = t * b.z + (1 - t) * a.z;
	return s;
}

int main() {
	point A, B, P, S;
	double l, m, r;

	ifstream ifs;
	ifs.open("connect.inp");

	ifs >> A.x >> A.y >> A.z >> B.x >> B.y >> B.z >> P.x >> P.y >> P.z;

	S = parametric(A, B, 0.5);

	l = distance(A, P);
	m = distance(S, P);
	r = distance(B, P);

	do {
		if (l < r) {
			r = m;
			B = S;
			S = parametric(A, B, 0.5);
			m = distance(S, P);
		}
		else {
			l = m;
			A = S;
			S = parametric(A, B, 0.5);
			m = distance(S, P);
		}
	} while (r - l > 0.001 || r - l < -0.001);

	ofstream ofs;
	ofs.open("connect.out");

	if (l < r) ofs << (int)(l + 0.99) << endl;
	else ofs << (int)(r + 0.99) << endl;

	ifs.close();
	ofs.close();

	return 0;
}