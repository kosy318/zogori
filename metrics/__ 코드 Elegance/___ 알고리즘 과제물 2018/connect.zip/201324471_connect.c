#include <stdio.h>
#include<stdlib.h>
#include<math.h>
#pragma warning(disable:4996)
int main()
{
	FILE *read;
	FILE *write;
	float p[9];//ax, ay, ay, bx, by, bz, xx, xy, xz;
	float atox, btox, atob; //�� ������ �Ÿ�
	float xv, yv, zv,dx,dy,dz,u;//�� ���⺤��,���� a�� ��Ÿ�� ��������
	float k; //�ø� ��
	int i,result;
	read = fopen("connect.inp", "r");
	write = fopen("connect.out", "w");
	for (i = 0; i < 9; i++)
	{
		fscanf(read, "%f", &p[i]);
	}
	atox = pow(p[0] - p[6], 2) + pow(p[1] - p[7], 2) + pow(p[2] - p[8], 2);
	btox = pow(p[3] - p[6], 2) + pow(p[4] - p[7], 2) + pow(p[5] - p[8], 2);
	atob = pow(p[0] - p[3], 2) + pow(p[1] - p[4], 2) + pow(p[2] - p[5], 2);
	if (atob>atox+btox)
	{
		xv = p[0] - p[3];
		yv = p[1] - p[4];
		zv = p[2] - p[5];
		dx = p[0] - p[6];
		dy = p[1] - p[7];
		dz = p[2] - p[8];
		k = sqrt( pow((yv*dz - zv*dy),2) + pow((zv*dx - xv*dz),2) + pow((xv*dy - yv*dx),2) ) / sqrt(pow(xv, 2) + pow(yv, 2) + pow(zv, 2));
		result = ceil(k); // �ø�

	}
	else if (atox >= atob + btox)
	{
		
		k = sqrt(btox);
		result = ceil(k);
	}
	else if (btox >= atox + atob)
	{
		k = sqrt(atox);
		result = ceil(k);
	}
	fprintf(write, "%d", result);
	return 0;
}