#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>

using namespace std;

int dist(double a[], double b[], double p[]);

int main() {
	double a[3];	// coordinates of point A
	double b[3];	// coordinates of point B
	double p[3];	// coordinates of point P

	ifstream inp("connect.inp", ios_base::in);
	ofstream out("connect.out", ios_base::out);

	if (inp.is_open()) {
		string line;

		// read all elements
		getline(inp, line);
		stringstream ss(line);
		ss >> a[0] >> a[1] >> a[2];
		getline(inp, line);
		ss.str(string()); ss.clear();
		ss << line;
		ss >> b[0] >> b[1] >> b[2];
		getline(inp, line);
		ss.str(string()); ss.clear();
		ss << line;
		ss >> p[0] >> p[1] >> p[2];

		inp.close();

		if (out.is_open()) {
			out << dist(a, b, p);
			out.close();
		}
	}
	return 0;
}

int dist(double a[], double b[], double p[]) {
	// middle point: S(t) = t*B + (1-t)*A, where t = 1/2
	double m[3] = { 0.5 * (b[0] + a[0]), 0.5 * (b[1] + a[1]), 0.5 * (b[2] + a[2]) };
	// distance from points a and b to point p
	double atop = sqrt(pow((a[0] - p[0]), 2) + pow((a[1] - p[1]), 2) + pow((a[2] - p[2]), 2));
	double btop = sqrt(pow((b[0] - p[0]), 2) + pow((b[1] - p[1]), 2) + pow((b[2] - p[2]), 2));

	if (ceil(atop) == ceil(btop)) // return distance from point m to point p
		return ceil(sqrt(pow((m[0] - p[0]), 2) + pow((m[1] - p[1]), 2) + pow((m[2] - p[2]), 2)));
	else if (atop < btop)
		return dist(a, m, p);
	else
		return dist(m, b, p);
}
