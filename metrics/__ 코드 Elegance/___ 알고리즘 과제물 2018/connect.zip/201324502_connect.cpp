#include <bits/stdc++.h>

using namespace std;

int main()
{
    double A[3], B[3], P[3], mid[3];
    ifstream fin("connect.inp");
    ofstream fout("connect.out");

    fin >> A[0] >> A[1] >> A[2];
    fin >> B[0] >> B[1] >> B[2];
    fin >> P[0] >> P[1] >> P[2];
    for(int i = 0; i < 3; i++) mid[i] = (A[i] + B[i])/2;

    for(int i = 0; i < 100; i++){
        double Ad = 0, Bd = 0;
        for(int i = 0; i < 3; i++){
            Ad += (A[i] - P[i])*(A[i] - P[i]);
            Bd += (B[i] - P[i])*(B[i] - P[i]);
        }
        if(Ad > Bd) for(int i = 0; i < 3; i++) A[i] = mid[i], mid[i] = (A[i] + B[i])/2;
        else        for(int i = 0; i < 3; i++) B[i] = mid[i], mid[i] = (A[i] + B[i])/2;
    }
    double distance = 0;
    for(int i = 0; i < 3; i++) distance += (mid[i] - P[i])*(mid[i] - P[i]);
    fout << ceil(sqrt(distance)) << "\n";

    return 0;
}
