#include <bits/stdc++.h>
#define D(x) (x)*(x)
using namespace std;
double x, y, z, ex, ey, ez, a, b, c, coef2, coef1, coef0, t;
fstream inf, outf;

double dist(double t){return ceil(sqrt(coef2*t*t + (-2)*coef1*t + coef0));}

int main(){
    inf.open("connect.inp", ios::in);
    outf.open("connect.out", ios::out);
    
    inf >> x >> y >> z;
    inf >> ex >> ey >> ez;
    inf >> a >> b >> c;
    coef2 = D(ex-x) + D(ey-y) + D(ez-z);
    coef1 = ((a-x)*(ex-x) + (b-y)*(ey-y) + (c-z)*(ez-z));
    coef0 = D(a-x) + D(b-y) + D(c-z);
    t = coef1/coef2;
    if(t < 0)
        outf << dist(0);
    else if(t > 1)
        outf << dist(1);
    else
        outf << dist(t);

    outf.close();
    inf.close();
    return 0;
}