#include <cstdio>
#include <cmath>
using namespace std;

class point3d {
public:
    double x,y,z;
    point3d(double _x,double _y,double _z) : x(_x), y(_y), z(_z) {}
};

inline double getMid(double x,double y) {
    return (x+y)/2;
}

point3d getMidPoint(const point3d& p1, const point3d p2) {
    return point3d(getMid(p1.x,p2.x), getMid(p1.y,p2.y), getMid(p1.z,p2.z));
}

double getDistSquare(const point3d& p1,const point3d& p2) {
    return (p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y)+(p1.z-p2.z)*(p1.z-p2.z);
}

bool boundCheck(double dep,double tar,double dest) {
    return (dep <= tar && tar <= dest) || (dest <= tar && tar <= dep);
}

bool boundCheck3dp(const point3d& dep, const point3d& tar, const point3d& dest) {
    return boundCheck(dep.x,tar.x,dest.x) && boundCheck(dep.y,tar.y,dest.y) && boundCheck(dep.z,tar.z,dest.z);
}

int main()
{

    freopen("connect.inp","r",stdin);
    freopen("connect.out","w",stdout);

    double x,y,z;
    scanf("%lf%lf%lf",&x,&y,&z);
    point3d st(x,y,z);
    scanf("%lf%lf%lf",&x,&y,&z);
    point3d ed(x,y,z);
    scanf("%lf%lf%lf",&x,&y,&z);
    point3d P(x,y,z);

    if(st.x > ed.x) {
        point3d Temp=st;
        st=ed;
        ed=Temp;
    }

    double ans;
    while(st.x <= ed.x) {
        double l=getDistSquare(P,st);
        double r=getDistSquare(P,ed);

        point3d M = getMidPoint(st,ed);

        if(l == r) {
            ans=getDistSquare(P,M);
            break;
        }
        else if(l < r) {
            ed=M;
        }
        else {
            st=M;
        }
    }

    printf("%g",ceil(sqrt(ans)));
    return 0;
}
