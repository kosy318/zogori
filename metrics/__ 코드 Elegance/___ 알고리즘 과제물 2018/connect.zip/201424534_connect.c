#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void inp_num(FILE *fp, double num[]);
void mid_num(double num1[], double num2[], double num3[]);
double len_num(double p1[], double p2[]);
void sht_len(double num_C[], double num_A[], double num_B[], double num_P[]);


int main()
{
    FILE *fp, *fp2;
    double num_A[3], num_B[3], num_P[3], num_C[3];

    fp = fopen("connect.inp", "r");

    inp_num(fp, num_A);
    inp_num(fp, num_B);
    inp_num(fp, num_P);

    fclose(fp);


    fp2 = fopen("connect.out", "w");
    sht_len(num_C, num_A, num_B, num_P);
    fprintf(fp2, "%.0f", ceil(len_num(num_C, num_P)));
    fclose(fp2);

    return 0;
}

void inp_num(FILE *fp, double num[])
{
    int i;
    for(i = 0; i < 3; i++) {
        fscanf(fp, "%lf", &num[i]);
    }
}

void mid_num(double num1[], double num2[], double num3[])
{
    int i;
    for(i = 0; i < 3; i++) {
        num3[i] = (num1[i] + num2[i]) / 2;
    }
}

double len_num(double p1[], double p2[])
{
    double num_dis[3], dis_p = 0;
    int j;
    for(j = 0; j < 3; j++) {
        num_dis[j] = pow(p1[j] - p2[j], 2.0);
        dis_p += num_dis[j];
    }
    return sqrt(dis_p);
}



void sht_len(double num_C[], double num_A[], double num_B[], double num_P[])
{
    double len[3];

    mid_num(num_A, num_B, num_C);

    len[0] = len_num(num_A, num_P);
    len[1] = len_num(num_C, num_P);
    len[2] = len_num(num_B, num_P);

    if(len[0] == len[1]) {
        mid_num(num_A, num_C, num_C);
    }
    if(len[0] == len[2]) {
        mid_num(num_A, num_B, num_C);
    }
    if(len[1] == len[2]) {
        mid_num(num_C, num_B, num_C);
    }

    if(len[0] < len[2]) {
        mid_num(num_A, num_B, num_B);
        sht_len(num_C, num_A, num_B, num_P);
    }
    else if(len[0] > len[2]) {
        mid_num(num_A, num_B, num_A);
        sht_len(num_C, num_A, num_B, num_P);
    }
}

