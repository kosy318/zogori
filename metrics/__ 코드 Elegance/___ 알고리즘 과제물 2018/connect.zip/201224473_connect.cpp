#include <iostream>
#include <fstream>
#include <math.h>
using namespace std;

// �ڸ�Ʈ ó�� �� �κ��� �̿ϼ� ����Ž���κ� �Դϴ�.

int main() {

	ifstream input("connect.inp");
	ofstream output("connect.out");

	long double * pa = new long double[3];
	long double * pb = new long double[3];
	long double * pp = new long double[3];
	long double * pm = new long double[3];
	int result = 0;
	//int k = 20;
	int index = 0;

	input >> pa[0];
	input >> pa[1];
	input >> pa[2];

	input >> pb[0];
	input >> pb[1];
	input >> pb[2];

	input >> pp[0];
	input >> pp[1];
	input >> pp[2];	

	/*pm[0] = (pa[0] + pb[0]) / 2;
	pm[1] = (pa[1] + pb[1]) / 2;
	pm[2] = (pa[2] + pb[2]) / 2;

	long double dap = (pa[0] - pp[0]) * (pa[0] - pp[0]) + (pa[1] - pp[1]) * (pa[1] - pp[1]) + (pa[2] - pp[2]) * (pa[2] - pp[2]);
	long double dbp = (pb[0] - pp[0]) * (pb[0] - pp[0]) + (pb[1] - pp[1]) * (pb[1] - pp[1]) + (pb[2] - pp[2]) * (pb[2] - pp[2]);
	long double dmp = (pm[0] - pp[0]) * (pm[0] - pp[0]) + (pm[1] - pp[1]) * (pm[1] - pp[1]) + (pm[2] - pp[2]) * (pm[2] - pp[2]);
	
	long double * new_ma = new long double[3];
	long double * new_mb = new long double[3];
	long double new_dmpa = 0;
	long double new_dmpb = 0;

	new_ma[0] = (pa[0] + pm[0]) / 2;
	new_ma[1] = (pa[1] + pm[1]) / 2;
	new_ma[2] = (pa[2] + pm[2]) / 2;

	new_mb[0] = (pb[0] + pm[0]) / 2;
	new_mb[1] = (pb[1] + pm[1]) / 2;
	new_mb[2] = (pb[2] + pm[2]) / 2;

	new_dmpa = (new_ma[0] - pp[0]) * (new_ma[0] - pp[0]) + (new_ma[1] - pp[1]) * (new_ma[1] - pp[1]) + (new_ma[2] - pp[2]) * (new_ma[2] - pp[2]);
	new_dmpb = (new_mb[0] - pp[0]) * (new_mb[0] - pp[0]) + (new_mb[1] - pp[1]) * (new_mb[1] - pp[1]) + (new_mb[2] - pp[2]) * (new_mb[2] - pp[2]);

	while (index < k) {
		if (new_dmpa < dmp) {
			long double * temp = new long double[3];
			temp[0] = pm[0];
			temp[1] = pm[1];
			temp[2] = pm[2];

			pm[0] = new_ma[0];
			pm[1] = new_ma[1];
			pm[2] = new_ma[2];
			dmp = new_dmpa;

			new_ma[0] = (pa[0] + pm[0]) / 2;
			new_ma[1] = (pa[1] + pm[1]) / 2;
			new_ma[2] = (pa[2] + pm[2]) / 2;

			new_mb[0] = (temp[0] + pm[0]) / 2;
			new_mb[1] = (temp[1] + pm[1]) / 2;
			new_mb[2] = (temp[2] + pm[2]) / 2;

			new_dmpa = (new_ma[0] - pp[0]) * (new_ma[0] - pp[0]) + (new_ma[1] - pp[1]) * (new_ma[1] - pp[1]) + (new_ma[2] - pp[2]) * (new_ma[2] - pp[2]);
			new_dmpb = (new_mb[0] - pp[0]) * (new_mb[0] - pp[0]) + (new_mb[1] - pp[1]) * (new_mb[1] - pp[1]) + (new_mb[2] - pp[2]) * (new_mb[2] - pp[2]);			
		}

		else if (new_dmpb < dmp) {
			long double * temp = new long double[3];
			temp[0] = pm[0];
			temp[1] = pm[1];
			temp[2] = pm[2];

			pm[0] = new_mb[0];
			pm[1] = new_mb[1];
			pm[2] = new_mb[2];
			dmp = new_dmpb;

			new_ma[0] = (temp[0] + pm[0]) / 2;
			new_ma[1] = (temp[1] + pm[1]) / 2;
			new_ma[2] = (temp[2] + pm[2]) / 2;

			new_mb[0] = (pb[0] + pm[0]) / 2;
			new_mb[1] = (pb[1] + pm[1]) / 2;
			new_mb[2] = (pb[2] + pm[2]) / 2;

			new_dmpa = (new_ma[0] - pp[0]) * (new_ma[0] - pp[0]) + (new_ma[1] - pp[1]) * (new_ma[1] - pp[1]) + (new_ma[2] - pp[2]) * (new_ma[2] - pp[2]);
			new_dmpb = (new_mb[0] - pp[0]) * (new_mb[0] - pp[0]) + (new_mb[1] - pp[1]) * (new_mb[1] - pp[1]) + (new_mb[2] - pp[2]) * (new_mb[2] - pp[2]);
		}
		index++;
	}

	result = (int)ceil(sqrt(dmp));

	if (dap < dmp) {
		result = (int)ceil(sqrt(dap));
	}

	else if (dbp < dmp) {
		result = (int)ceil(sqrt(dbp));
	}*/

	long double da_pow = (pa[0] - pp[0]) * (pa[0] - pp[0]) + (pa[1] - pp[1]) * (pa[1] - pp[1]) + (pa[2] - pp[2]) * (pa[2] - pp[2]);
	long double db_pow = (pb[0] - pp[0]) * (pb[0] - pp[0]) + (pb[1] - pp[1]) * (pb[1] - pp[1]) + (pb[2] - pp[2]) * (pb[2] - pp[2]);
	long double dab_pow = (pa[0] - pb[0]) * (pa[0] - pb[0]) + (pa[1] - pb[1]) * (pa[1] - pb[1]) + (pa[2] - pb[2]) * (pa[2] - pb[2]);
	long double k = (da_pow - db_pow + dab_pow) / (2 * sqrt(dab_pow));

	if (k < 0) {
		if (da_pow < db_pow) {
			result = (int)ceil(sqrt(da_pow));
		}
		else
			result = (int)ceil(sqrt(db_pow));
	}

	else {
		result = (int)ceil(sqrt(da_pow - k*k));
	}

	output << result;
	input.close();
	output.close();
	return 0;
}