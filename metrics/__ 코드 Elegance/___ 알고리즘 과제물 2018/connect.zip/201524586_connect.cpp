#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
using namespace std;

typedef struct point {
    float coord_x, coord_y, coord_z;
} point;

point point_A, point_B, point_P;

int min_distance;

void ReadFile();
void Find_Shortest();
float cal_Distance(point X, point Y);
void WriteFile();

int main(int argc, char** argv) {
	ReadFile();
	Find_Shortest();
	WriteFile();
	return 0;
}

void ReadFile(){
	ifstream inFile("connect.inp");
	inFile >> point_A.coord_x >> point_A.coord_y >> point_A.coord_z;
	inFile >> point_B.coord_x >> point_B.coord_y >> point_B.coord_z;
	inFile >> point_P.coord_x >> point_P.coord_y >> point_P.coord_z;
	inFile.close();	
}

void Find_Shortest(){
	point M;
	M.coord_x = (point_A.coord_x + point_B.coord_x) / 2;
	M.coord_y = (point_A.coord_y + point_B.coord_y) / 2;
	M.coord_z = (point_A.coord_z + point_B.coord_z) / 2;
	
	float disAP = cal_Distance(point_A, point_P);
	float disBP = cal_Distance(point_B, point_P);
	float disMP = cal_Distance(M, point_P);
	
	while ( ceil(disAP) != ceil(disBP) || ceil(disAP) != ceil(disMP)){
		if ( disAP > disBP ){
			point_A = M;
			M.coord_x = (point_A.coord_x + point_B.coord_x) / 2;
			M.coord_y = (point_A.coord_y + point_B.coord_y) / 2;
			M.coord_z = (point_A.coord_z + point_B.coord_z) / 2;
			disAP = cal_Distance(point_A, point_P);
			disBP = cal_Distance(point_B, point_P);
			disMP = cal_Distance(M, point_P);
		}
		else {
			point_B = M;
			M.coord_x = (point_A.coord_x + point_B.coord_x) / 2;
			M.coord_y = (point_A.coord_y + point_B.coord_y) / 2;
			M.coord_z = (point_A.coord_z + point_B.coord_z) / 2;
			disAP = cal_Distance(point_A, point_P);
			disBP = cal_Distance(point_B, point_P);
			disMP = cal_Distance(M, point_P);
		}
	}
	min_distance = ceil(disAP);	
}


float cal_Distance(point X, point Y){
	return sqrt( pow(X.coord_x-Y.coord_x,2) + pow(X.coord_y - Y.coord_y,2) + pow(X.coord_z - Y.coord_z ,2 ));
}

void WriteFile(){
	ofstream outFile("connect.out");
	outFile << min_distance << endl;
	outFile.close();	
}
