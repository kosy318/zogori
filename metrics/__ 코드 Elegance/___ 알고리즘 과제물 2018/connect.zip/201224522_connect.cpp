#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>

using namespace std;

const string infilename = "connect.inp";
const string outfilename = "connect.out";

// s = t * B + ( 1 - t ) * A
void parametric(double t, double a[], double b[], double s[]) {
	s[0] = t * a[0] + (1 - t) * b[0];
	s[1] = t * a[1] + (1 - t) * b[1];
	s[2] = t * a[2] + (1 - t) * b[2];
}

double getDistance(double s[], double d[]) {
	return sqrt(pow(s[0] - d[0], 2) + pow(s[1] - d[1], 2) + pow(s[2] - d[2], 2));
}

int main() {
	// read
	ifstream infs(infilename);
	if (infs.is_open()) {
		int result = 0;
		double Acoor[3], Bcoor[3], Pcoor[3];	// A,B,P �� x, y, z ��ǥ
		
		double prevDistance, distance;
		bool prevSlope, slope; // T : ��, F : ��
		double t = 0.5;
		double tUpperBound = 1.0, tLowerBound = 0.0;
		double Epsilon = 0.0001;
		double tempS[3];

		// input �ޱ�
		for (int i = 0; i < 3; i++) {
			infs >> Acoor[i];
		}
		for (int i = 0; i < 3; i++) {
			infs >> Bcoor[i];
		}
		for (int i = 0; i < 3; i++) {
			infs >> Pcoor[i];

		}

		infs.close();

		//search
		// ������ �߰� ������ �Ÿ��� �Ÿ��׷����� ���� ���ϱ�
		parametric(t, Acoor, Bcoor, tempS);
		prevDistance = getDistance(tempS, Pcoor);
		parametric(t + Epsilon, Acoor, Bcoor, tempS);
		if (prevDistance - getDistance(tempS, Pcoor) >= 0) {
			prevSlope = false;	// �Ÿ� ���Ⱑ ��
		}
		else {
			prevSlope = true;	// �Ÿ� ���Ⱑ ��	
		}

		// prevDistance�� �����κа� distance�� �����κ��� ���� prevSlope�� slope�� �ٸ��� ���� ����������
		bool loopExit = false;
		while (!loopExit) {
			if (prevSlope) {
				tUpperBound = t;
				t = tLowerBound + ((tUpperBound - tLowerBound) / 2);
			}
			else {
				tLowerBound = t;
				t = tLowerBound + ((tUpperBound - tLowerBound) / 2);
			}

			parametric(t, Acoor, Bcoor, tempS);
			distance = getDistance(tempS, Pcoor);
			parametric(t + Epsilon, Acoor, Bcoor, tempS);
			if (distance - getDistance(tempS, Pcoor) >= 0) {
				slope = false;	// �Ÿ� ���Ⱑ ��
			}
			else {
				slope = true;	// �Ÿ� ���Ⱑ ��	
			}



			// prev�� ��
			if ((int)prevDistance == (int)distance && prevSlope != slope) {
				loopExit = true;
				result = ceil(distance);
			}
			else if (abs(t - 1.0) < 0.000000001) {
				// B���� �Ÿ�
				result = ceil(distance);
				loopExit = true;
			}
			else if (abs(t - 0.0) < 0.000000001) {
				// A���� �Ÿ�
				result = ceil(distance);
				loopExit = true;
			}
			else {
				prevDistance = distance;
				prevSlope = slope;
			}

		}


		//write
		ofstream outfs(outfilename);
		if (outfs.is_open()) {
			outfs << result;

			outfs.close();
		}
		else {
			cout << "wrong output" << endl;
		}

	}
	else {
		cout << "wrong input" << endl;
	}

	return 0;
}