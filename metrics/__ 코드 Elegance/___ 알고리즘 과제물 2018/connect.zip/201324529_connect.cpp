#include<iostream>
#include<fstream>
#include<cmath>

using namespace std;

double a1, a2, a3;
double b1, b2, b3;
double x, y, z;
double result;

void input() {
	ifstream fin;
	fin.open("connect.inp");
	fin >> a1 >> a2 >> a3;
	fin >> b1 >> b2 >> b3;
	fin >> x >> y >> z;
	fin.close();
}

void output() {
	ofstream fout;
	fout.open("connect.out");
	fout << result;
	fout.close();
}
void process() {
	while (1) {
		if (ceil((a1 - x)*(a1 - x) + (a2 - y)*(a2 - y) + (a3 - z)*(a3 - z)) == ceil((b1 - x)*(b1 - x) + (b2 - y)*(b2 - y) + (b3 - z)*(b3 - z))) {
			result = ceil(sqrt((a1 - x)*(a1 - x) + (a2 - y)*(a2 - y) + (a3 - z)*(a3 - z)));
			break;
		}
		if (((a1 - x)*(a1 - x) + (a2 - y)*(a2 - y) + (a3 - z)*(a3 - z)) > ((b1 - x)*(b1 - x) + (b2 - y)*(b2 - y) + (b3 - z)*(b3 - z))) {
			a1 = (a1 + b1) / 2; a2 = (a2 + b2) / 2; a3 = (a3 + b3) / 2;
		}
		if (((a1 - x)*(a1 - x) + (a2 - y)*(a2 - y) + (a3 - z)*(a3 - z)) < ((b1 - x)*(b1 - x) + (b2 - y)*(b2 - y) + (b3 - z)*(b3 - z))) {
			b1 = (a1 + b1) / 2; b2 = (a2 + b2) / 2; b3 = (a3 + b3) / 2;
		}
	}
}

int main() {
	input();
	process();
	output();
}