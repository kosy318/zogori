#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

int main()
{
    double x[3] = {0};
    double y[3] = {0};
    double z[3] = {0};
    double lenA, lenB;

    ifstream fin;
    fin.open("connect.inp");
    for(int i=0; i<3; i++)
        fin >> x[i] >> y[i] >> z[i];
    fin.close();

    while(1) {
        lenA = sqrt(pow((x[0]-x[2]),2) + pow((y[0]-y[2]),2) + pow((z[0]-z[2]),2));
        lenB = sqrt(pow((x[1]-x[2]),2) + pow((y[1]-y[2]),2) + pow((z[1]-z[2]),2));
        if(lenA > lenB) {
            x[0]=(x[0]+x[1])/2;
            y[0]=(y[0]+y[1])/2;
            z[0]=(z[0]+z[1])/2;
        }
        else if(lenA < lenB) {
            x[1]=(x[0]+x[1])/2;
            y[1]=(y[0]+y[1])/2;
            z[1]=(z[0]+z[1])/2;
        }
        else
            break;
    }

    ofstream fout;
    fout.open("connect.out");
    fout << ceil(lenA);
    fout.close();

    return 0;
}
