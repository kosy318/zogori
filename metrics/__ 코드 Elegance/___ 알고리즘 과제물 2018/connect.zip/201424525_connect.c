#include <stdio.h>
#include <math.h>

struct Point {
	double x, y, z;
};

// return the distance between two points
double distance(struct Point* p1, struct Point* p2) {
	double result = pow((p1->x - p2->x), 2.0) + pow((p1->y - p2->y), 2.0) + pow((p1->z - p2->z), 2.0);
	result = sqrt(result);
	return result;
}

// return whether two points have same values or not
short equalPoint(struct Point* p1, struct Point* p2) {
	if (p1->x == p2->x && p1->y == p2->y && p1->z == p2->z)
		return 1;
	else
		return 0;
}

int main(void)
{
	FILE *infp, *outfp;
	struct Point A, B, P;
	double inputData[9] = {0.0, };
	double AP, BP;
	int i;
	
	// open the file 
	infp = fopen("connect.inp", "rt");
	if (infp == NULL) {
		printf("Error: Cannot read the file..!\n");
		return -1;
	}

	// read the file
	for (i = 0; i < 9 && fscanf(infp, "%lf", &inputData[i]) != EOF; ++i)
		;
	fclose(infp);

	// assign points
	A.x = inputData[0];
	A.y = inputData[1];
	A.z = inputData[2];
	B.x = inputData[3];
	B.y = inputData[4];
	B.z = inputData[5];
	P.x = inputData[6];
	P.y = inputData[7];
	P.z = inputData[8];

	do {
		AP = distance(&A, &P);
		BP = distance(&B, &P);

		// compare AP and BP and decide the way of progress
		if (AP == BP && equalPoint(&A, &B) == 0) {
			A.x = (A.x + B.x) / 2.0;
			A.y = (A.y + B.y) / 2.0;
			A.z = (A.z + B.z) / 2.0;
			AP = distance(&P, &A);
		}
		else if (AP < BP) {
			B.x = (A.x + B.x) / 2.0;
			B.y = (A.y + B.y) / 2.0;
			B.z = (A.z + B.z) / 2.0;
		}
		else if (AP > BP) {
			A.x = (A.x + B.x) / 2.0;
			A.y = (A.y + B.y) / 2.0;
			A.z = (A.z + B.z) / 2.0;
		}
	} while (AP != BP);
	
	// write the file
	outfp = fopen("connect.out", "wt");
	if (outfp == NULL) {
		printf("Error: Cannot make the file..!\n");
		return -2;
	}
	fprintf(outfp, "%d\n", (int)ceil(AP));
	fclose(outfp);

	return 0;
}
