#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

double point_a[3],
  point_b[3],
  point_p[3],
  point_t[3];

double getDist(double t) {
//t를 이용해 거리를 구하는 부분
  point_t[0] = t * point_b[0] + (1 - t) * point_a[0];
  point_t[1] = t * point_b[1] + (1 - t) * point_a[1];
  point_t[2] = t * point_b[2] + (1 - t) * point_a[2];
  double result = sqrt(pow((point_p[0] - point_t[0]), 2) + pow((point_p[1] - point_t[1]), 2) + pow((point_p[2] - point_t[2]), 2));

  cout << t << " : " << result << endl;

  return result;

}

int checkDist(double t) {
  cout << "checkDist : " << t << endl;
  if (getDist(t - 0.01) < getDist(t)) {
    return -1;
  } else if (getDist(t) > getDist(t + 0.01)) {
    return 1;
  } else {
    return 0;
  }
}

int main() {
  ifstream fInput("./connect.inp");
  ofstream fResult("./connect.out");

  int index = 0;
  double t = 0;

  if (fInput.is_open()) {
    while (!fInput.eof()) {
      if (index == 0) {
        fInput >> point_a[0] >> point_a[1] >> point_a[2];
        index++;
      } else if (index == 1) {
        fInput >> point_b[0] >> point_b[1] >> point_b[2];
        index++;
      } else {
        fInput >> point_p[0] >> point_p[1] >> point_p[2];
      }
    }

    if (getDist(0) < getDist(0.01)) {
      cout << getDist(0) << " 이거다!(맨첫값)" << endl;
      fResult << getDist(0) << endl;

    } else if (getDist(1) < getDist(0.99)) {
      cout << getDist(1) << " 이거다!(맨뒷값)" << endl;
      fResult << getDist(1) << endl;
    } else {
      t = 0.5;
      int signal, times = 2;
      while (true) {
        signal = checkDist(t);
        cout << "signal : " << signal << endl;
        if (signal < 0) {
          //왼쪽으로 가야되
          t = t - (1 / pow(times, 2));
          times++;
        } else if (signal > 0) {
          //오른쪽
          t = t + (1 / pow(times, 2));
          times++;
        } else {
          //here
          break;
        }
      }

      cout << "중간값 " << t << " : " << ceil(getDist(t)) << endl;
      fResult << ceil(getDist(t)) << endl;
    }


  } else {
    cout << "파일 열기 실패" << endl;
  }
  fResult.flush();
  fInput.close();
  fResult.close();

  return 0;
}


