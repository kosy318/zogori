#include <stdio.h>
#include <cmath>
#include <iostream>
#include <fstream>
using namespace std;

struct position
{
	double x, y, z;
} a, b, c;

double x_to_y[1001];

double length(double x, double y, double z) {
	return sqrt(x*x + y*y + z*z);
}

double binary_search(int left, int right) { 
	if(left > right) return -1;
	
	int mid = left + (right - left) / 2;
	if( left+1 == right ) return x_to_y[left];
	else if (x_to_y[left] < x_to_y[right]) {
		return binary_search(left, mid - 1);
	}
	else if(x_to_y[left] > x_to_y[right]) {
		return binary_search(mid + 1, right);
	}
}

int main() {
    ifstream fin;
    ofstream fout;
    fin.open("connect.inp");
    fout.open("connect.out");
	fin >> a.x >> a.y >> a.z;
	fin >> b.x >> b.y >> b.z;
	fin >> c.x >> c.y >> c.z;

	double t = 0;    
    
    while( t <= 1 ) {
		int i = t * 1000;
    	x_to_y[i] = length((t*a.x + (1-t)*b.x) - c.x, (t*a.y + (1-t)*b.y) - c.y, (t*a.z + (1-t)*b.z) - c.z);
    	t = t+0.001;
	}
    
    fout << ceil(binary_search(0, 999));
    

    return 0;
}   

