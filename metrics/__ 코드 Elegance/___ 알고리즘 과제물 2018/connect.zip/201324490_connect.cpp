#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
int main() {
	ifstream fin("connect.inp");
	ofstream fout("connect.out");
	int A_x, A_y, A_z, B_x, B_y, B_z, P_x, P_y, P_z;

	fin >> A_x >> A_y >> A_z;
	fin >> B_x >> B_y >> B_z;
	fin >> P_x >> P_y >> P_z;

	int AB_x, AB_y, AB_z, AP_x, AP_y, AP_z;
	long long up, down;

	AB_x = B_x - A_x;
	AB_y = B_y - A_y;
	AB_z = B_z - A_z;
	AP_x = P_x - A_x;
	AP_y = P_y - A_y;
	AP_z = P_z - A_z;

	down = pow(AB_x, 2) + pow(AB_y, 2) + pow(AB_z, 2);
	up = pow(AB_x * AP_y - AB_y * AP_x, 2) + pow(AB_y * AP_z - AB_z * AP_y, 2) +
		pow(AB_z * AP_x - AB_x * AP_z, 2);

	double  result = sqrt(up / down);
	if (result / 1 != 0)
		fout << (int)result + 1 << endl;
	else
		fout << result << endl;

	fin.close();
	fout.close();
	return 0;
}