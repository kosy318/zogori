#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

double t = 0;
double dis,mindis;

double A[3];
double B[3];
double P[3];
double point[3];

void infile() {
   ifstream inf;
      inf.open("connect.inp");

      inf >> A[0] >> A[1]>> A[2];
      inf >> B[0] >> B[1]>> B[2];
      inf >> P[0] >> P[1]>> P[2];
}

void connect_function(){

   mindis = sqrt(pow((P[0] - B[0]), 2) + pow((P[1] - B[1]), 2) + pow((P[2] - B[2]), 2));

   while (t < 1) {
        t = t + 0.001;
        point[0] = t* A[0] + (1-t)* B[0];
        point[1] = t* A[1] + (1-t)* B[1];
        point[2] = t* A[2] + (1-t)* B[2];
        //printf("%f %f %f", P[0], point.y, point.z);
        dis = sqrt(pow((P[0] - point[0]), 2) + pow((P[1] - point[1]), 2) + pow((P[2] - point[2]), 2));
      if (dis < mindis) {
           mindis = dis;
        }
          else break;
      }
   }

void outfile() {
   ofstream outf;
   outf.open("connect.out");

   outf << ceil(mindis);

   outf.close();

}


int main() {
   infile();
   connect_function();
   outfile();
}
