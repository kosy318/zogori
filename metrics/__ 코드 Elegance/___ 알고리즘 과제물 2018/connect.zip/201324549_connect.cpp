#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;

int main(){
	double PointA[3];
	double PointB[3];
	double PointP[3];
	double A_P;
	double B_P;
	
	ifstream fin("connect.inp");
	ofstream fout("connect.out");
	
	fin >> PointA[0] >> PointA[1] >> PointA[2];
	fin >> PointB[0] >> PointB[1] >> PointB[2];
	fin >> PointP[0] >> PointP[1] >> PointP[2];
	
	fin.close();

	A_P = (PointA[0] - PointP[0])*(PointA[0] - PointP[0]) + (PointA[1] - PointP[1])*(PointA[1] - PointP[1]) + (PointA[2] - PointP[2])*(PointA[2] - PointP[2]) ;
	B_P = (PointB[0] - PointP[0])*(PointB[0] - PointP[0]) + (PointB[1] - PointP[1])*(PointB[1] - PointP[1]) + (PointB[2] - PointP[2])*(PointB[2] - PointP[2]) ;
	
	
	while(1) {
		if(ceil(B_P) == ceil(A_P)){
			A_P = sqrt(A_P);
			A_P = ceil(A_P);
			fout << A_P;
			break;	
		}
		else if(B_P > A_P) {
			for(int i =0; i<3; i++){
				PointB[i] = (PointB[i]+PointA[i])/2;
			}
			B_P = (PointB[0] - PointP[0])*(PointB[0] - PointP[0]) + (PointB[1] - PointP[1])*(PointB[1] - PointP[1]) + (PointB[2] - PointP[2])*(PointB[2] - PointP[2]) ;
			
		}
		else if(B_P < A_P) {
			for(int i =0; i<3; i++){
				PointA[i] = (PointB[i]+PointA[i])/2;
			}
			A_P = (PointA[0] - PointP[0])*(PointA[0] - PointP[0]) + (PointA[1] - PointP[1])*(PointA[1] - PointP[1]) + (PointA[2] - PointP[2])*(PointA[2] - PointP[2]) ;
		}
	}
	return 0;
	
	
}
