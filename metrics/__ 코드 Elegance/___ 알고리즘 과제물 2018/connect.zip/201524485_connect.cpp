#include <iostream>
#include <fstream>
#include <cmath>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

using namespace std;

typedef struct Point{
	float x;
	float y;
	float z;
} Point;


int result;

void findDis(Point A, Point B, Point P){
	float disA, disB, disH, min;
	Point H;
	H.x = 0.5*A.x +0.5*B.x;
	H.y = 0.5*A.y +0.5*B.y;
	H.z = 0.5*A.z +0.5*B.z;
	disA = sqrt(pow(A.x - P.x, 2) + pow(A.y - P.y, 2) + pow(A.z - P.z, 2));
	disB = sqrt(pow(B.x - P.x, 2) + pow(B.y - P.y, 2) + pow(B.z - P.z, 2));
	disH = sqrt(pow(H.x - P.x, 2) + pow(H.y - P.y, 2) + pow(H.z - P.z, 2));
	if(disA <= disB){
		min = disA;
	}else{
		min = disB;
	}
	while(ceil(disA) != ceil(disB) ||ceil(min) != ceil(disH)){
		if(disA <= disB){
			B = H;
			min = disA;
		} else{
			A = H;
			min = disB;
		}
		H.x = 0.5*A.x +0.5*B.x;
		H.y = 0.5*A.y +0.5*B.y;
		H.z = 0.5*A.z +0.5*B.z;
		disA = sqrt(pow(A.x - P.x, 2) + pow(A.y - P.y, 2) + pow(A.z - P.z, 2));
		disB = sqrt(pow(B.x - P.x, 2) + pow(B.y - P.y, 2) + pow(B.z - P.z, 2));
		disH = sqrt(pow(H.x - P.x, 2) + pow(H.y - P.y, 2) + pow(H.z - P.z, 2));
	}
	result = ceil(disA);
}

void readFile(){
	Point A, B, P;
	ifstream input("connect.inp");
	input >> A.x >> A.y >> A.z;
	input >> B.x >> B.y >> B.z;
	input >> P.x >> P.y >> P.z;
	findDis(A, B, P);

}

void writeFile(){
	ofstream output("connect.out");
	output << result << endl;
}

int main(int argc, char** argv) {
	readFile();
	writeFile();
	return 0;
}
