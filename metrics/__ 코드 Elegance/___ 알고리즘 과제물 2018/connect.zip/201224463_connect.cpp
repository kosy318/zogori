#include <iostream>
#include <fstream>
#include <math.h>
#include <algorithm>

using namespace std;
int n;

struct Point {
	double x;
	double y;
	double z;
};
double dist(Point A, Point B) {
	return sqrt(pow((A.x - B.x),2) + pow((A.y - B.y),2) + pow((A.z - B.z),2));
}

Point search(Point A, Point B, Point P)
{
	Point S;
	while (1) {
		if (dist(A, P) > dist(B, P)) {
			A.x = (A.x + B.x) / 2;
			A.y = (A.y + B.y) / 2;
			A.z = (A.z + B.z) / 2;
		}
		else if (dist(A, P) < dist(B, P)) {
			B.x = (A.x + B.x) / 2;
			B.y = (A.y + B.y) / 2;
			B.z = (A.z + B.z) / 2;
		}
		else {
			S.x = (A.x + B.x) / 2;
			S.y = (A.y + B.y) / 2;
			S.z = (A.z + B.z) / 2;
			break;
		}
	}
	return S;
}

int main()
{
	ifstream in;
	ofstream out;

	Point A, B, P;
	in.open("connect.inp");
	out.open("connect.out");

	in >> A.x >> A.y >> A.z;
	in >> B.x >> B.y >> B.z;
	in >> P.x >> P.y >> P.z;
	
	out << ceil(dist(search(A, B, P), P));
	in.close();
	out.close();
	return 0;
}