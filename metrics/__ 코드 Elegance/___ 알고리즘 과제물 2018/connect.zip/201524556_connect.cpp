#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<math.h>
#include <algorithm>  

using namespace std;


int main()
{
	ifstream inpFile("connect.inp");
	ofstream outFile("connect.out");
	string info, info2, info3, buf;
	stringstream stream1, stream2, stream3;
	string X1, X2, X3, Y1, Y2, Y3, Z1, Z2, Z3;
	double x1, x2, x3, y1, y2, y3, z1, z2, z3;
	double px, py, pz;
	getline(inpFile, info);
	stream1.str(info);
	stream1 >> X1 >> Y1 >> Z1;
	x1 = stoi(X1);
	y1 = stoi(Y1);
	z1 = stoi(Z1);

	getline(inpFile, info2);
	stream2.str(info2);
	stream2 >> X2 >> Y2 >> Z2;

	x2 = stoi(X2);
	y2 = stoi(Y2);
	z2 = stoi(Z2);

	getline(inpFile, info3);
	stream3.str(info3);
	stream3 >> X3 >> Y3 >> Z3;
	x3 = stoi(X3);
	y3 = stoi(Y3);
	z3 = stoi(Z3);



	double t = -1 * ((x1 - x2)*(x1 - x3) + (y1 - y2)*(y1 - y3) + (z1 - z2)*(z1 - z3)) / (pow(x1 - x2, 2) + pow(y1 - y2, 2) + pow(z1 - z2, 2));
	px = (x1 - x2)*t + x1;
	py = (y1 - y2)*t + y1;
	pz = (z1 - z2)*t + z1;

	double distance = sqrt((px - x3)*(px - x3) + (py - y3)*(py - y3) + (pz - z3)*(pz - z3));
	if ((min(x1, x2) < px&&max(x1, x2) > px&&min(y1, y2) < py&&max(y1, y2) > py&&min(z1, z2) < pz&&max(z1, z2) > pz) != 1)
	{
		int da = sqrt(pow(x1 - x3, 2) + pow(y1 - y3, 2) + pow(z1 - z3, 2));
		int db = sqrt(pow(x2 - x3, 2) + pow(y2 - y3, 2) + pow(z2 - z3, 2));
		distance = min(da, db);
	}


	if (distance > (int)distance)
		outFile << ((int)distance + 1);
	else
		outFile << (int)distance;

	return 0;


}