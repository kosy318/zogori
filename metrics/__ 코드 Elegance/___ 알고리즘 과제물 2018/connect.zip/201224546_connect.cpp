#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;
int Ax, Ay, Az;
int Bx, By, Bz;
int Px, Py, Pz;

double evalTilt(double var)
{
	return 2 * ((Bx - Ax) * var + Ax - Px) *(Bx - Ax) + 2 * ((By - Ay) * var + Ay - Py) *(By - Ay) + 2 * ((Bz - Az) * var + Az - Pz) *(Bz - Az);
}

double FindMinLen(double left, double right)
{
	double leftTilt = evalTilt(left);//2 * ((Bx - Ax) * left + Ax - Px) *(Bx - Ax) + 2 * ((By - Ay) * left + Ay - Py) *(Bx - Ay) + 2 * ((Bz - Az) * left + Az - Pz) *(Bz - Az);
	double rightTilt = evalTilt(right);//2 * ((Bx - Ax) * right + Ax - Px) *(Bx - Ax) + 2 * ((By - Ay) * right + Ay - Py) *(Bx - Ay) + 2 * ((Bz - Az) * right + Az - Pz) *(Bz - Az);
	if (leftTilt >= 0)
		return sqrt(pow((Bx - Ax) * left + Ax - Px, 2) + pow((By - Ay) * left + Ay - Py, 2) + pow((Bz - Az) * left + Az - Pz, 2));
	else if (rightTilt <= 0)
		return sqrt(pow((Bx - Ax) * right + Ax - Px, 2) + pow((By - Ay) * right + Ay - Py, 2) + pow((Bz - Az) * right + Az - Pz, 2));
	else if (leftTilt < 0 && rightTilt > 0)
	{
		if (evalTilt((left + right) / 2) < 0)
			return FindMinLen((left + right) / 2, right);
		else if ((int)(evalTilt((left + right) / 2) * 100000000) == 0)
		{
			return sqrt(pow((Bx - Ax) * (left + right) / 2 + Ax - Px, 2) + pow((By - Ay) * (left + right) / 2 + Ay - Py, 2) + pow((Bz - Az) * (left + right) / 2 + Az - Pz, 2));
		}
		else
			return FindMinLen(left, (left + right) / 2);
	}
}

int main(void)
{
	ifstream inputFile("connect.inp", ios::in);
	ofstream outputFile("connect.out", ios::out);


	inputFile >> Ax >> Ay >> Az;
	inputFile >> Bx >> By >> Bz;
	inputFile >> Px >> Py >> Pz;


	int ans;
	double length;

	length = FindMinLen(0, 1);

	if ((int)length < length)
		ans = (int)length + 1;

	outputFile << ans << endl;

	return 0;
}
