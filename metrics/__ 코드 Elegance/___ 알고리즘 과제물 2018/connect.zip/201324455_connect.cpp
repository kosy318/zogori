#include <fstream>
#include <math.h>
using namespace std;
int main() {
	int dot[9];
	double dis[3], ipr = 0;
	ifstream inf("connect.inp");
	ofstream outf("connect.out");
	for (int i = 9; i != 0; i--) inf >> dot[9 - i];
	for (int i = 0; i < 3; i++) {
		dot[i] -= dot[i + 3];
		dot[i + 6] -= dot[i + 3];
		ipr += dot[i] * dot[i + 6];
	}
	dis[0] = (dot[0] * dot[0]) + (dot[1] * dot[1]) + (dot[2] * dot[2]);
	dis[1] = (dot[6] * dot[6]) + (dot[7] * dot[7]) + (dot[8] * dot[8]);
	if (ipr < 0) outf << (int)ceil(sqrt(dis[1]));
	else if ((ipr * ipr) > (dis[0] * dis[0])) outf << (int)ceil(sqrt(pow(dot[0] - dot[6], 2) + pow(dot[1] - dot[7], 2) + pow(dot[2] - dot[8], 2)));
	else outf << (int)ceil(sqrt(dis[1] - (ipr * ipr / dis[0])));
	inf.close();
	outf.close();
	return 0;
}
