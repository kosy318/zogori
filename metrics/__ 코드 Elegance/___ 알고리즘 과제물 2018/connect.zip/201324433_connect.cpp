#include<iostream>
#include <fstream>
#include <algorithm>
#include <math.h>
using namespace std;

int main() {
	int A_x, A_y, A_z;
	int B_x, B_y, B_z;
	int P_x, P_y, P_z;
	
	ifstream fin;
	fin.open("connect.inp");
	fin >> A_x >> A_y >> A_z;
	fin >> B_x >> B_y >> B_z;
	fin >> P_x >> P_y >> P_z;
	fin.close();

	int result;
	double t = 0.0;
	result = min(ceil(sqrt(pow(P_x - B_x, 2) + pow(P_y - B_y, 2) + pow(P_z - B_z, 2))),
		ceil(sqrt(pow(P_x - A_x, 2) + pow(P_y - A_y, 2) + pow(P_z - A_z, 2))));
	while (t < 1) {
		t += 0.001;
		int temp = ceil(sqrt(pow(P_x - (t*B_x + (1 - t)*A_x), 2) + pow(P_y - (t*B_y + (1 - t)*A_y), 2) + pow(P_z - (t*B_z + (1 - t)*A_z), 2)));
		if (temp < result) result = temp;
		//else if (temp > result) break;
	}
	ofstream fout;
	fout.open("connect.out");
	fout << result;
	cout << result;
}