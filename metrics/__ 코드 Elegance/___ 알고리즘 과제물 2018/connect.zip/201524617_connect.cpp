#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

double a_arr[3],b_arr[3],p[3];
double bottom=0,top=1;

int openfile();
void connect();
void re_array(double arr[3],double t);
double length(double y[3],double z[3]);

int main()
{
    int nothing=openfile();

    if(nothing==1)
        connect();

    return 0;
}


int openfile()
{
    ifstream fin;
    fin.open("connect.inp");
    if(!fin) { cout<<"file open file"; return 0; }

    for(int i=0;i<3;++i)
        fin>>a_arr[i];
    for(int i=0;i<3;++i)
        fin>>b_arr[i];
    for(int i=0;i<3;++i)
        fin>>p[i];

    return 1;
}


void connect()
{
    ofstream fout;
    fout.open("connect.out");

    double len1,len2;
    double a[3]={a_arr[0],a_arr[1],a_arr[2]};
    double b[3]={b_arr[0],b_arr[1],b_arr[2]};

    if(  (a[0]==b[0]) &&  (a[1]==b[1])  &&  (a[2]==b[2])   )    {   len1=length(a,p);   }
    else {
    while(bottom!=top){
           
		    len1=length(a,p);
            len2=length(b,p);

            if(len1==len2)      {   bottom=(bottom+top)/2; 		re_array(a,bottom); len1=length(a,p);    break;   }
            else if(len1>len2)	{     bottom=(bottom+top)/2;    re_array(a,bottom);     }
            else if(len1<len2)	{     top=(bottom+top)/2;		re_array(b,top);    	}

    }
    }

    len1=sqrt(len1);
    fout<<(int)(ceil(len1));

}

void re_array(double arr[3],double t)
{
    arr[0]=t*b_arr[0]+(1-t)*a_arr[0];
    arr[1]=t*b_arr[1]+(1-t)*a_arr[1];
    arr[2]=t*b_arr[2]+(1-t)*a_arr[2];
}

double length(double y[3],double z[3])
{
    double length=(y[0]-z[0])*(y[0]-z[0]) + (y[1]-z[1])*(y[1]-z[1]) + (y[2]-z[2])*(y[2]-z[2]);
    return length;
}
