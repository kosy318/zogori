#include <cstdio>
#include <math.h>

using namespace std;

float Ax, Ay, Az, Bx, By, Bz, Px, Py, Pz;
float minDistance;

void input() {
	FILE *fp = fopen("connect.inp", "r");
	fscanf(fp, "%f %f %f ", &Ax, &Ay, &Az);
	fscanf(fp, "%f %f %f", &Bx, &By, &Bz);
	fscanf(fp, "%f %f %f", &Px, &Py, &Pz);
	fclose(fp);
}

float getDistance(float _ax, float _ay, float _az, float _bx, float _by, float _bz) {
	float centerX = (_ax + _bx) / 2;
	float centerY = (_ay + _by) / 2;
	float centerZ = (_az + _bz) / 2;
	float distanceA, distanceB, distanceCenter;
	distanceA = (Px - _ax) * (Px - _ax) + (Py - _ay) * (Py - _ay) + (Pz - _az) * (Pz - _az);
	distanceB = (Px - _bx) * (Px - _bx) + (Py - _by) * (Py - _by) + (Pz - _bz) * (Pz - _bz);
	distanceCenter = (Px - centerX) * (Px - centerX) + (Py - centerY) * (Py - centerY) + (Pz - centerZ) * (Pz - centerZ);

	if (fabsf(distanceA - distanceCenter) <= 1 || fabsf(distanceB - distanceCenter) <= 1) {
		return sqrt(distanceCenter);
	}
	else {
		if (distanceA > distanceB) {
			return getDistance(centerX, centerY, centerZ, _bx, _by, _bz);
		}
		else {
			return getDistance(_ax, _ay, _az, centerX, centerY, centerZ);
		}
	}
}

void process() {
	minDistance = getDistance(Ax, Ay, Az, Bx, By, Bz);
}

void output() {
	FILE *fp = fopen("connect.out", "w");
	fprintf(fp, "%d\n", (int)ceil(minDistance));
	fclose(fp);
}
int main() {
	input();
	process();
	output();
	return 0;
}