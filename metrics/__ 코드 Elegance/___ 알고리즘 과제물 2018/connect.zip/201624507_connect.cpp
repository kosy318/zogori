#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <math.h>


using namespace std;

int main()
{
    ifstream fin("connect.inp");
    ofstream fout("connect.out");

    string line;
    float p_1 [3] = {0.0,};
    float p_2 [3] = {0.0,};
    float p_3 [3] = {0.0,};
    float d_1, d_2;
    int p1, p2, re;

    for(int i=0; i<3; i++){
        fin >> p_1[i];
    }
    for(int i=0; i<3; i++){
        fin >> p_2[i];
    }
    for(int i=0; i<3; i++){
        fin >> p_3[i];
    }

    d_1 = sqrt(pow(p_1[0]-p_3[0],2)+pow(p_1[1]-p_3[1],2)+pow(p_1[2]-p_3[2],2));
    d_2 = sqrt(pow(p_2[0]-p_3[0],2)+pow(p_2[1]-p_3[1],2)+pow(p_2[2]-p_3[2],2));
    p1 = (int)p_1[1];
    p2 = (int)p_2[1];

    while (p1!=p2){
        if (d_1>d_2){
            for (int i=0; i<3; i++){
                p_1[i] = (p_1[i] + p_2[i])/2;
            }
        }
        else {
            for (int i=0; i<3; i++){
                p_2[i] = (p_1[i] + p_2[i])/2;
            }
        }
        d_1 = sqrt(pow(p_1[0]-p_3[0],2)+pow(p_1[1]-p_3[1],2)+pow(p_1[2]-p_3[2],2));
        d_2 = sqrt(pow(p_2[0]-p_3[0],2)+pow(p_2[1]-p_3[1],2)+pow(p_2[2]-p_3[2],2));
        p1 = (int)p_1[1];
        p2 = (int)p_2[1];
    }

    re = ceil(d_1);
    cout << re;

    fout << re;

    fin.close();
    fout.close();
    return 0;
}
