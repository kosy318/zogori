#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;

class Point{
public:
    double x;
    double y;
    double z;
};

void fun(){
    Point A, B, P;
    double distance1, distance2, new_dist;
    ifstream ifs;
    ofstream ofs;
    ifs.open("connect.inp");
    ofs.open("connect.out");

    ifs >> A.x >> A.y >> A.z
    >>B.x >> B.y >> B.z
    >>P.x >>P.y >> P.z;

    while(1) {
        distance1 = sqrt(pow(A.x-P.x,2)+pow(A.y-P.y,2)
                         +pow(A.z-P.z,2));
        distance2 = sqrt(pow(B.x-P.x,2)+pow(B.y-P.y,2)
                         +pow(B.z-P.z,2));
        if(distance1 > distance2) {
            A.x = (A.x+B.x)/2; A.y = (A.y+B.y)/2; A.z = (A.z+B.z)/2;
        }
        else if(distance1 < distance2) {
            B.x = (A.x+B.x)/2; B.y = (A.y+B.y)/2; B.z = (A.z+B.z)/2;
        }
        else{
            new_dist = sqrt(pow((A.x+B.x)/2-P.x,2)+pow((A.y+B.y)/2-P.y,2)
                         +pow((A.z+B.z)/2-P.z,2));
            break;
        }
        if( fabs(distance1 - distance2) < 0.001) {
            new_dist = distance1;
            break;
        }
    }
    if(new_dist - (int)new_dist==0)
        ofs << new_dist;
    else ofs << (int)new_dist+1;

}

int main()
{
    fun();
    return 0;
}
